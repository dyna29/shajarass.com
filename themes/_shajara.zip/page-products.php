<?php 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?>
 <style>
 img.img-fluid.product-brand {
    border: 1px solid rgb(118,194,27) !important;
    transform: unset !important;
}
 </style>
  <!-- Header Start -->
    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Products</h1>
                  <!---  <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url()?>">Home</a></li>
                            
                            <li class="breadcrumb-item text-white active" aria-current="page">Products</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


     <!-- Categories Start -->
    <div class="container-xxl py-5 category">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                  	<h5 class="sub-title left">Our <span>Products</span></h5>

		    <h1 class="mb-4  left ">Solutions provided by 3S</h1>
            </div> 
                    <div class="row g-3">
					<?php
		$brands =  get_terms(array(
								'taxonomy' => 'brand',
								'hide_empty' => false,'parent'=>0
							) ); 
foreach($brands as $brand){
  
							?>
                        <div class="col-lg-3 wow zoomIn" data-wow-delay="0.1s">
                    <a class="position-relative d-block overflow-hidden" href="<?php echo site_url().'/brand/'.$brand->slug;?>">
                                <img class="img-fluid product-brand" src="<?php echo   get_field('products_page_brand_image',$brand); ?>" alt="">
                             
                            </a>
                        </div>
                     
                 
							<?php
							 
						} 
						?>
                 
            </div>
        </div>
    </div>
    <!-- Categories Start -->

  
  	<?php
	 
	endwhile;  
	get_footer();?>  