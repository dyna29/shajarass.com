<?php 

	/*
	*Template Name: Event Template  
	*/ 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?>
  <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Event</h1>
                    <!---<nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url();?>">Home</a></li>
                            
                            <li class="breadcrumb-item text-white active" aria-current="page">Event</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

    <!-- About Start -->
    <div class="container-fluid py-5  bg-white about-us-section">
        <div class="container">
            <div class="row  ">
			
                <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.3s">
                    	 

		    <h1 class="mb-4    " style="text-align:center"><?php echo get_the_title();?></h1>
                    <div style="text-align:center"><?php the_content();?>

</div>
                     
                   
                </div>
                </div>
				
        
        </div>
    </div>
   
	   
 
    <!-- Courses Start -->
	<style>
	body{
	background: #eee;
}
.section-padding{
	width:1170px;
	margin: 0 auto;
	padding:80px 0;
}

.owl-item .item {
   transform: translate3d(0, 0, 0); /* DO NOT REMEMBER WHERE TU PUT THIS, SEARCH FOR 3D ACCELERATION */
  // transform: scale(0.9);

  // transition: all .25s ease-in-out;  
 }

.screenshot_slider .owl-item .item .product-item {
background:#fff;
    -webkit-transition: 0.3s;
    -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    -o-transition: 0.3s;
    transition: 0.3s;
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
}

.screenshot_slider .owl-item.center .item .product-item {
    -webkit-transform: scale(1.50);
    -ms-transform: scale(1.50);
    transform: scale(1.50); 
}

.owl-carousel.screenshot_slider  .owl-stage-outer {
   overflow-y:unset !important;
    height: 350px;
}
.screenshot_slider .owl-nav {
    text-align: center;
    // margin: 40px 0;
}
.product-item-pad {
    width: 100%;
    padding: 30px;
}
.screenshot_slider .owl-nav button {
	font-size: 24px !important;
	margin: 10px;
	color: #033aff !important;
}
	</style>
     
   
     <?php
	 
	endwhile;  
	get_footer();?>