<?php 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?>
  <!-- Header Start -->
    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Services</h1>
                 <!---   <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url()?>">Home</a></li>
                            
                            <li class="breadcrumb-item text-white active" aria-current="page">Services</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


     <!-- Categories Start -->
    <div class="container-xxl py-5 category">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                  	<h5 class="sub-title left">Our <span>Services</span></h5>

		    <h1 class="mb-4  left ">Solutions provided by 3S</h1>
            </div> 
                    <div class="row g-3">
					<?php
							$args = array(	'post_type' => array('service'),
						'posts_per_page' => -1,  
						'post_parent'	=>0,
						'orderby'   => 'id',
						'order' => 'ASC',
						'orderby'   => 'ID', 
         
						); 
						$loop = new WP_Query($args);
						$i=0; 
						if($loop->have_posts()) {
							$online=1;
							$show_paging = 0;

							while($loop->have_posts()) : $loop->the_post();
							 $serviceimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
  
							?>
                        <div class="col-lg-4 wow zoomIn" data-wow-delay="0.1s">
                            <a class="position-relative d-block overflow-hidden" href="<?php echo get_permalink();?>">
                                <div  style="background:url(<?php echo   $serviceimage[0]; ?>)" alt="" class="service-img"></div>
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                    <h5 class="m-0"><?php echo get_the_title();?></h5>
                                    
                                </div>
                            </a>
                        </div>
                     
                 
							<?php
							endwhile;
							wp_reset_postdata(); 
						} 
						?>
                 
            </div>
        </div>
    </div>
    <!-- Categories Start -->

  
  	<?php
	 
	endwhile;  
	get_footer();?>  