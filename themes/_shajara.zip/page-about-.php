<?php 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?>
  <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">About us</h1>
                    <!---<nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url();?>">Home</a></li>
                            
                            <li class="breadcrumb-item text-white active" aria-current="page">About us</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

    <!-- About Start -->
    <div class="container-fluid py-5  bg-white about-us-section">
        <div class="container">
            <div class="row  ">
			
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    	<h5 class="sub-title left">welcome to <span>Shajara Sustainability Solutions</span></h5>

		    <h1 class="mb-4  left ">The best solution for sustainability</h1>
                    <p class="mb-4">Shajara Sustainability Solutions (3S) is a sustainability energy products and service provider that was established in 2022 in
 Kuwait with focus on providing their services through out the world. 3S is a subsidiary of Al-Shajara holding, which was established in 1978 with focus on developing variety of business in the Middle East region.

</p> 
                     
                   
                </div>
          
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" >
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="<?php echo get_field('about_side_image'); ?>" alt="" style="object-fit: cover;">
                    </div>
                </div>
               
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- About Start -->
    <div class="container-xxl py-5 founder-section">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" >
                    <div class="position-relative h-100">
                    <div class="message-img">
			 <div class="message-img-1" style="background:url(<?php echo get_stylesheet_directory_uri(); ?>/img/ceo-dr-ameer.jpg)"></div>
                <!-- <div class="message-img-2" style="background:url(<?php echo get_stylesheet_directory_uri(); ?>/img/faceless-man-keeping-bulb-with-plant_23-2147826212.jpg)"></div>-->
                  </div>
                  </div>
                </div>
             <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
              <div class="message-block">
               	<h5 class="sub-title left">CEO Welcome <span>Message</span></h5>
		   <!-- <h1 class="mb-4  left ">From the CEO</h1>-->
                    <p class="founder-message">
					"Sustainability is not any more part of the social responsibility or a commodity that only some people can have access to, it’s the way to save the planet!"<br><br>
<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/ameer_signature.png"class="founder-name"> 
 
					</p>
                   
                </div>
                </div>
            </div>
        </div>
    </div>
	  <div class="container-xxl py-5 mission-vision-values">
	   <div class="container">
            <div class="row g-5">
			 <div class="col-md-12  wow  fadeInUp">
			  <div class="mvv-box">
				  <div class="mvv-icon"><img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-goal-100.png" class="icon-color" > </div>
				  <h2>Mission</h2>
				  <p>Shajara Sustainability Solutions (3S) goal is to deliver ready and suitable energy solutions to our clients and serve their requirements under the Environmental, suitability and Government (ESG) mandates. 
				</p>
			  </div>
			</div>
			 <div class="col-md-12  wow  fadeInUp">
			  <div class="mvv-box pull-right">		  <div class="mvv-icon"><img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-vision-100-2.png" class="icon-color" > </div>
				  <h2 class="">Vision</h2>
				  <p><!--To position it self as one of the lead product and serves distributors of sustainability solutions in the region-->
				  Support contractors developers and end users in supplying top and Cutting Edge the renewable energy equipments in the MENA region.


				</p>
			  </div>
			</div>
			 <div class="col-md-12  wow  fadeInUp">
			  <div class="mvv-box">		  <div class="mvv-icon"><img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-scales-100.png" class="icon-color" > </div>
				  <h2>Values</h2>
				  <p>Varity of clean solutions with access to multiple markets

				</p>
			  </div>
			</div>
    </div>
    </div>
    </div>
	
	<!-- <div class="container-xxl py-5 our-team">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                
					<h5 class="sub-title  ">Our <span>Team</span></h5>

		    <h1 class="mb-4    ">Meet our experts</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/team-1.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Jack Jones</h5>
                            <small>Designation</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/team-2.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Jack Jones</h5>
                            <small>Designation</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/team-3.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Jack Jones</h5>
                            <small>Designation</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/team-4.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Jack Jones</h5>
                            <small>Designation</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>-->
    <!-- About End -->

 
    <!-- Courses Start -->
	<style>
	body{
	background: #eee;
}
.section-padding{
	width:1170px;
	margin: 0 auto;
	padding:80px 0;
}

.owl-item .item {
   transform: translate3d(0, 0, 0); /* DO NOT REMEMBER WHERE TU PUT THIS, SEARCH FOR 3D ACCELERATION */
  // transform: scale(0.9);

  // transition: all .25s ease-in-out;  
 }

.screenshot_slider .owl-item .item .product-item {
background:#fff;
    -webkit-transition: 0.3s;
    -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    -o-transition: 0.3s;
    transition: 0.3s;
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
}

.screenshot_slider .owl-item.center .item .product-item {
    -webkit-transform: scale(1.50);
    -ms-transform: scale(1.50);
    transform: scale(1.50); 
}

.owl-carousel.screenshot_slider  .owl-stage-outer {
   overflow-y:unset !important;
    height: 350px;
}
.screenshot_slider .owl-nav {
    text-align: center;
    // margin: 40px 0;
}
.product-item-pad {
    width: 100%;
    padding: 30px;
}
.screenshot_slider .owl-nav button {
	font-size: 24px !important;
	margin: 10px;
	color: #033aff !important;
}
	</style>
     
   
     <?php
	 
	endwhile;  
	get_footer();?>