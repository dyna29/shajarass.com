<?php
   /*
   *Template Name: Demo Template
   */ 
   get_header();
    
    while ( have_posts() ) : the_post();
    $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
     
   ?>   
<!-- About Start -->
<div class="container-xxl py-5  ">
   <div class="container">
      <div class="row ">
         <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
            <!-- Courses Start -->
            <style>
               .owl-carousel .item {
               /* background: #3498db; */
               /* color: white; */
               padding: 0;
               text-align: center;
               font-size: 15px;
               border-radius: 10px;
               margin: 10px;
               }
               .nav-button {
               position: absolute;
               top: 50%;
               transform: translateY(-50%);
               background: rgb(255 255 255 / 64%);
               color: rgb(0 0 0);
               border: none;
               padding: 15px;
               font-size: 20px;
               cursor: pointer;
               border-radius: 50%;
               z-index: 100;
               }
               .nav-button:hover {
               background: rgb(255 255 255);
               }
               #prev {
               left: 150px;
               }
               #next {
               right: 150px;
               }
               .news-thumb {
               height: 250px;
               background-size: cover !important;
               background-position: center center !important;
               width: 100%;
               }
               h3.news-title {
               font-size: 16px;
               padding:10px 10px;
               height: 50px;text-align:left;
               }
               .news-excerpt{
               text-align:left;
               padding:10px 10px;
               }
               /* Second Carousel Styles */
               .image-slider-container {
               margin: auto;
               text-align: center;
               }
               .main-slider .item img {
               width: 100%;
               border-radius: 10px;
               }
               .thumbnail-slider .item img {
               width: 100px;
               height: 60px;
               object-fit: cover;
               cursor: pointer;
               border: 2px solid transparent;
               border-radius: 5px;
               }
               .thumbnail-slider .item img:hover, .thumbnail-slider .item.active img {
               border: 2px solid #3498db;
               }
               .detailed-news-container {
               position: fixed;
               top: 0px;
               left: 0px;
               background: #0000004a;
               z-index: 99999999;
               height: 100vh;
               display: none
               ;
               align-items: center;
               justify-content: center;width: 100%;
               }
               .detailed-news {
               width: 80%;
               background: #fff;
               padding: 30px;
               position: relative;
               }
               .detailed-news-container.active {
               display: flex;
               }
               .news-box {
               cursor: pointer;
               }
               .news-box {
               cursor: pointer;
               transition: .5s;
               border: 1px solid rgb(82 86 91 / 21%);
               }
               .news-box:hover {
               margin-top: -10px;
               background: #76c21b;
               }
               a.close-news {
               position: absolute;
               right: -10px;
               color: #000;
               font-size: 20px;
               top: -10px;
               background: #e7e0e0;
               /* padding: 5px 10px; */
               border-radius: 57px;
               width: 30px;
               height: 30px;
               display: flex
               ;
               align-items: center;
               justify-content: center;
               }
            </style>
            <div class="carousel-container">
               <button id="prev" class="nav-button">←</button>
               <div class="owl-carousel owl-theme" id="news-slider">
                  <?php
                     $args = array(	'post_type' => array('news'),
                     'posts_per_page' => -1,  
                     'post_parent'	=>0,
                     'orderby'   => 'id',
                     'order' => 'ASC',
                     'orderby'   => 'ID', 
                       
                     ); 
                     $loop = new WP_Query($args);
                     $i=0; 
                     if($loop->have_posts()) {
                     $online=1;
                     $show_paging = 0;
                     
                     while($loop->have_posts()) : $loop->the_post();
                      $newsimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
                     
                     ?>
                  <div class="item">
                     <div class="news-box"  boxid = "<?php echo get_the_id();?>">
                        <div class="news-thumb" style="background:url(<?php echo $newsimage[0];?>)"></div>
                        <h3 class="news-title"><?php echo get_the_title();?></h3> <h5 class="news-title"><?php echo get_field('news_date');?></h5>
                        <div class="news-excerpt"><?php echo substr(strip_tags(get_the_content()),0,50);?>....</div>
                     </div>
                  </div>
                  <?php
                     endwhile;
                     wp_reset_postdata(); 
                     } 
                     ?>
               </div>
               <button id="next" class="nav-button">→</button>
            </div>
            <?php
               $args = array(	'post_type' => array('news'),
               'posts_per_page' => -1,  
               'post_parent'	=>0,
               'orderby'   => 'id',
               'order' => 'ASC',
               'orderby'   => 'ID', 
                 
               ); 
               $loop = new WP_Query($args);
               $i=0; 
               if($loop->have_posts()) {
               $online=1;
               $show_paging = 0;
               
               while($loop->have_posts()) : $loop->the_post();
                $newsimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
               
               ?>
            <div class="detailed-news-container detailed-news-container-<?php echo get_the_id();?>">
               <div class="detailed-news">
                  <a href="javascript:void())" boxid = "<?php echo get_the_id();?>" class="close-news">x</a>
                  <div class="row ">
                     <div class="col-lg-6" >
                         <style>
 
/* Main Gallery Layout */
.gallery {
    max-width: 600px;
    margin: auto;
    text-align: center;
}

/* Big Display Area */
.big-display img {
    width: 100%;
    height: auto;
    max-height: 350px;
    object-fit: cover;
    border-radius: 8px;
    border: 2px solid #ccc;
}

/* Thumbnail Scrollable Area */
.thumbnail-container {
    overflow-x: auto;
    padding: 10px;
    background: #fff;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(128, 128, 128, 0.25); 
}
.thumbnails::-webkit-scrollbar {
  height: 5px;
}

/* Track */
.thumbnails::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius:  0px;
}
 
/* Handle */
.thumbnails::-webkit-scrollbar-thumb {
  background: #000; 
  border-radius: 0px;
}

/* Handle on hover */
.thumbnails::-webkit-scrollbar-thumb:hover {
  background: #76c21b; 
}
/* Thumbnails Wrapper - Using CSS Grid */
.thumbnails {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    grid-auto-flow: column;
    gap: 10px;
    overflow-x: auto;
    scroll-snap-type: x mandatory;
}

/* Individual Thumbnails */
.news-thumb-box {
    width: 100px;
    height: 70px;
    border: 2px solid transparent;
    cursor: pointer; 
    overflow: hidden;
    transition: border 0.3s ease;
    scroll-snap-align: start;  width: 100px;
}
 
video  {
    width: 100%;
}
.big-preview {
    text-align: center;
    margin-bottom: 15px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(128, 128, 128, 0.25);
    padding: 10px;
}
.news-slider-thumb {
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: center;
}

/* Active Thumbnail */
.news-thumb-box.active {
    border: 2px solid #76c21b !important;
}
 
/* Hide scrollbar for cleaner look */
.thumbnail-container::-webkit-scrollbar {
    display: none;
}
.news-sldier-thumb{
	    height: 70px;
    background-size: cover !important;
    background-position: center center !important;
    width: 100%;
}
.main-media {
    width: 100%;
    height: 350px;
    background-size: cover !important;
    background-position: center center !important;
    background-repeat: no-repeat !important;
}
</style>
 

<div class="gallery-container">
    <!-- Big Display Area -->
    <div class="big-preview">
        <img src="https://via.placeholder.com/800x450" id="mainMedia-<?php echo get_the_id();?>" alt="Main Preview">
    </div>

    <!-- Thumbnails -->
    <div class="thumbnail-container">
        <div class="thumbnails">
           
             <?php	
$i = 0;
			 while ( have_rows('images') ) : the_row();
$i++;
$image = get_sub_field('image');
$image_url = wp_get_attachment_image_url( $image, 'gallery-thumb-btn' );
$image_url2 = wp_get_attachment_image_url( $image, 'full' );
if($i==1){
	$initiateclass="initiate-first";
}else{
	$initiateclass="";
}
 ?> 
   <div class="thumb-<?php echo get_the_id();?> news-thumb-box  <?php echo $initiateclass;?>" data-type="image" data-src="<?php echo $image_url2;?>"  >
                <div style="background:url(<?php echo $image_url;?>)" class="news-sldier-thumb"></div>
            </div>
 <?php
  endwhile;
  
  ?>
  
             <?php	
 
			 while ( have_rows('videos') ) : the_row();
$i++;
$image = get_sub_field('video');
$thumbnail = get_sub_field('thumbnail');
$image_url = wp_get_attachment_image_url( $thumbnail, 'gallery-thumb-btn' ); 
if($i==1){
	$initiateclass="initiate-first";
}else{
	$initiateclass="";
}
 ?> 
   <div class="thumb-<?php echo get_the_id();?> news-thumb-box <?php echo $initiateclass;?>" data-type="video" data-src="<?php echo $image;?>"  >
                <div style="background:url(<?php echo $image_url;?>)" class="news-sldier-thumb"></div>
            </div>
 <?php
  endwhile;
  
  ?>
        </div>
    </div>
</div>

 

<script>
$(document).ready(function () {
    $(".thumb-<?php echo get_the_id();?>").click(function () {
        let type = $(this).data("type");
        let src = $(this).data("src");

        // Remove active class from all and add to clicked
        $(".thumb-<?php echo get_the_id();?>").removeClass("active");
        $(this).addClass("active");

        if (type === "image") {
            $("#mainMedia-<?php echo get_the_id();?>").replaceWith(`<div class="main-media" style="background:url(${src})" id="mainMedia-<?php echo get_the_id();?>" alt="Main Preview"></div>`);
        } else if (type === "video") {
            $("#mainMedia-<?php echo get_the_id();?>").replaceWith(`
                <video id="mainMedia-<?php echo get_the_id();?>" controls autoplay>
                    <source src="${src}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            `);
        }
    });
});

</script>
                     </div>
                     <div class="col-lg-6" >
                        <h3 class="news-title"><?php echo get_the_title();?></h3>
                        <div class="full-news"><?php echo get_the_content();?></div>
                     </div>
                  </div>
               </div>
            </div>
            <?php
               endwhile;
               wp_reset_postdata(); 
               } 
               ?>
         </div>
      </div>
   </div>
</div>
<!-- About Start -->
<style>
ul.team-container li {
    display: inline-block;
    width: 33.33%;
    margin-bottom: 30px;
}
ul.team-container {
    padding: 0px;
}
.team-pic {
    background-size: cover !important;
    background-position: center center !important;
    width: 100%;
    height: 400px;    
}
.team-member {
    position: relative;
}
.team-info {
    position: absolute;
    bottom: 0px;
    left: 0px;
    height: 100%;
    width: 100%;
    background: rgb(0 0 0 / 56%);
    padding: 15px;
	top:calc(400px - 80px);
	transition:all 600ms ease-in-out;
}
.team-member {
    position: relative;
    overflow: hidden;
}
 
.team-content {
    color: #fff;
    font-size: 14px;
}
.team-title{
	height:80px;
}

.team-title h3 {
    height: 30px;
    color: #fff;
}
.team-title h4 {
    height: 30px;
    color: #fff;
    font-size: 18px;
}
.team-member:hover .team-info {
    top: 200px;
}

#prev {
    left: 30px;
    top: 35%;
}

#next {
    right: 30px;
    top: 35%;
}


@media (max-width: 800px){
.detailed-news-container {
    position: fixed;
    top: 10vh;
    left: 0px;
    background: #0000004a;
    z-index: 99999999;
    height: 80vh;
    display: none;
    align-items: center;
    justify-content: center;
    width: 100%;
}	
	ul.team-container li { 
    width:100%; 
}
.full-news {
    overflow-y: scroll;
    height: 30vh;
}

    .main-media {
        height: 250px;
    }
 
.detailed-news { 
    padding: 15px; 
}
h3.news-title {
    font-size: 16px;
    padding: 10px 0px;
    height: 50px;
    text-align: left;
}
.detailed-news {
    width: 90%; 
}

}
</style>
<div class="container-xxl py-5  ">
   <div class="container">
      <div class="row ">
         <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
            <!-- Courses Start -->
           
            <ul class="team-container row">
                
              
                  <?php
                     $args = array(	'post_type' => array('team'),
                     'posts_per_page' => -1,  
                     'post_parent'	=>0,
                     'orderby'   => 'id',
                     'order' => 'ASC',
                     'orderby'   => 'ID', 
                       
                     ); 
                     $loop = new WP_Query($args);
                     $i=0; 
                     if($loop->have_posts()) {
                     $online=1;
                     $show_paging = 0;
                     
                     while($loop->have_posts()) : $loop->the_post();
                      $teamimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
                     
                     ?>
                  <li  >
                     <div class="team-member"  >
                        <div class="team-pic" style="background:url(<?php echo $teamimage[0];?>)"></div>
                        <div class="team-info">
						<div class="team-title"><h3 ><?php echo get_the_title();?></h3>
						<h4 ><?php echo get_field('designation');?></h3>
						</div>
							<div class="team-content"><?php echo get_the_content();?></div>
						</div>
                     </div>
                  </li>
                  <?php
                     endwhile;
                     wp_reset_postdata(); 
                     } 
                     ?>
               </ul> 
            </div>
           
         </div>
      </div>
   </div>
</div>
<!-- About End -->
<?php
   endwhile;  
   get_footer();?> 
<script>
   $(document).ready(function(){
   
   jQuery(".close-news").click(function(){
   
   boxid = jQuery(this).attr("boxid")
   jQuery(".detailed-news-container-"+boxid).removeClass("active")
   
   });
   jQuery(".news-box").click(function(){
   
   boxid = jQuery(this).attr("boxid")
  
   
   jQuery(".detailed-news-container-"+boxid).addClass("active")
   jQuery('.initiate-first').trigger('click')
   })
   
     
     
       var owl = $("#news-slider").owlCarousel({
           loop: false,
           margin: 10,
           nav: false,
           dots: false,
           autoplay: false,
           autoplayTimeout: 3000,
           autoplayHoverPause: true,
           responsive: {
               0: { items: 1 },
               600: { items: 2 },
               1000: { items: 4 }
           }
       });
   
       $("#prev").click(function() {
           owl.trigger("prev.owl.carousel");
       });
   
       $("#next").click(function() {
           owl.trigger("next.owl.carousel");
       });
   
   });
</script>