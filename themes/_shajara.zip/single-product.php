<?php 
	get_header('brand');
	 
	 while ( have_posts() ) : the_post();
	 $featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 
 $terms = get_the_terms( get_the_ID(), 'brand' ); 
    foreach($terms as $term) {
      $brand_name =  $term->name; 
	   
	  
    }
	$sub_brand_name  = "";
	$brand_logo = get_field( 'image', $terms[0] );
	$template_color = get_field( 'template_color', $terms[0] );
	 
	
	if(isset($terms[1])){
		 $sub_brand_name =  $terms[1]->name; 
     
	}
	
?>
<style>
.owl-thumbs.row button.col-md-3 {
    border: 1px solid #fff;
    background: #fff;
    width: 25%;
}
.insize{
  max-width:600px;
}
.owl-thumbs{}
.owl-thumbs .owl-thumb-item {
    display: inline-block;
    height: auto;
    width: 100%;
    max-width: 150px;
    background: transparent;
    border: none;
    overflow: hidden;
    padding: 0px;
}
.owl-thumbs .owl-thumb-item img{
  max-width:100%;
  height:auto;
}
.owl-dots{
  position:absolute;
  bottom:170px;
  left:0;
  right:0;
}
.owl-thumbs .owl-thumb-item img {
    margin-top: 3px;
    max-width: 100%;
    height: auto;
    border: 3px solid #fff;
    margin-left: 3px;
}
.product-owl{
overflow: hidden;

}
.owl-thumbs.row img {
    width: 100%;
}
.owl-thumbs.row button.col-md-3 {
    border: 1px solid #fff;
    background: #fff;
}

a.datasheet-btn,a.enquire-now {
    background-color: rgb(118, 194, 27);
    border-color: rgb(118, 194, 27);
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
    isplay: inline-block;
    font-weight: 400;
    line-height: 1.5;
    color: #52565b;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    user-select: none;
    /* background-color: transparent; */
    /* border: 1px solid transparent; */
    padding: .375rem .75rem;
    font-size: 1rem;
    border-radius: 0px;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    color: #fff;
    margin-top: 15px !important;
    display: block; 
}
.owl-carousel .owl-item img {
    display: block;
    width: 100%;
    border: 1px solid #52565b36;
	 
}
.owl-thumbs.row {
    margin-top: 30px;
}
.hiddenfield{
	display:none;
}
section.grey-bg.enquire {
    padding: 50px;
}
.grey-bg {
    background: #eeeeee;
}
.enquiry-box {
    box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    border: 5px solid #fff;
    background: #fff;
    padding: 50px;
    padding-bottom: 0px;
}
textarea.wpcf7-form-control.wpcf7-textarea {
    height: 100px;   display: block;
    width: 100%;
    padding: .375rem .75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #52565b;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    appearance: none;
    border-radius: 0px;
}
.enquiry-box label {
    width: 100%;
}
.hiddenfield{
	display:none !important;
}
input.wpcf7-form-control.wpcf7-submit  {
    width: 200px;
    background-color: rgb(118, 194, 27);
    border-color: rgb(118, 194, 27);
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
    isplay: inline-block;
    font-weight: 400;
    line-height: 1.5;
    color: #52565b;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    user-select: none;
    /* background-color: transparent; */
    /* border: 1px solid transparent; */
    padding: .375rem .75rem;
    font-size: 1rem;
    border-radius: 0px;
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    color: #fff; 
    display: block;
}
input.wpcf7-form-control ,select.wpcf7-form-control  {
    display: block;
    width: 100%;
    padding: .375rem .75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #52565b;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    appearance: none;
    border-radius: 0px;
    transition: bor;
}

a.datasheet-btn  ,a.enquire-now{
	background:<?php echo $template_color;?>;
}
input.wpcf7-form-control.wpcf7-submit { 
    background-color: <?php echo $template_color;?>;
    border-color:<?php echo $template_color;?>;
}
.btn-primary {
    color: #000;
    background-color:  <?php echo $template_color;?>;
    border-color: <?php echo $template_color;?>;
}
ul.btns li {
    width: 50%;
}
ul.btns {
    list-style: none;
    padding: 0px;
}
</style>

 <!-- Header Start -->
    <!-- Header Start  
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown"><?php echo get_the_title();?>
</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                               <li class="breadcrumb-item"><a class="text-white" href="index.php">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url('services');?>">Services</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page"><?php echo get_the_title();?>
</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    Header End -->

     <!-- About Start -->
    <div class="container-xxl py-5  bg-white about-us-section">
        <div class="container">
            <div class="row g-5">
			
             
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                   <div class="container insize">
  <div class="owl-carousel owl-theme product-owl" data-slider-id="1">
 <?php  
 $galleryitems = 0;
 while ( have_rows('gallery') ) : the_row(); 
 $galleryitems++; 
 ?>
    <div class="item"><img src="<?php echo get_sub_field('image');?>" alt="zoom" class="alignleft size-medium wp-image-7000" /></div>
    <?php endwhile; 

    ?>
    
</div>
</div>

                </div>
				<?php 
				   if($galleryitems == 1){
?>
<style>
    .owl-thumbs.row {
    display: none;
}
    </style>
<?php
   } 
				?>
                   <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
				 
				   <?php if($sub_brand_name !=""){ ?>
				    <h3 class=" subbrand  animated slideInDown"><?php echo $sub_brand_name;?>
</h3>
				   <?php } ?>
                    <h1 class="  animated slideInDown"><?php echo get_the_title();?>
</h1>
 <?php if(get_field('phase') !="") { ?><strong>PHASE:</strong> <span><?php echo get_field('phase');?></span> <?php } ?>
                     <?php echo str_replace("\r\n","bb",get_field('content'));?>
                    <ul class="btns row">
					<li> 
                    <?php 
					if(get_field('datasheet')!=""){
						
						?>
						<a href="<?php echo get_field('datasheet');?>" target="_blank" class="datasheet-btn small-btns">Download Datasheet</a>
						<?php
					}
					?>
					</li>
					<li>
					<a href="#inquire"  class=" small-btns enquire-now">Inquire</a>
					
					</li>
					</ul>
                </div>
            </div>
        </div>
    </div>
	
	<section class="grey-bg enquire" id="inquire">
	<h1 class="mb-4 text-center ">Send Enquiry</h1>
	 <div class="container">
            <div class="row g-5">
            <div class="col-md-12"><div class="enquiry-box">
	<?php echo do_shortcode('[contact-form-7 id="ba1b72e" title="Enquiry"]');?>
                </div> </div></div>
            </div>
	</section>
    <!-- About End -->

	<?php
	 
	endwhile;  
	get_footer();?> 
<script>
/*! OwlCarousel2Thumbs - v0.1.3 | (c) 2015 @gijsroge | MIT license | https://github.com/gijsroge/OwlCarousel2-Thumbs */
!function(a){"use strict";var b=function(c){this.owl=c,this._thumbcontent=[],this.owl_currentitem=this.owl.options.startPosition,this.$element=this.owl.$element,this._handlers={"prepared.owl.carousel":a.proxy(function(b){if(b.namespace&&this.owl._options.thumbs&&!this.owl._options.thumbImage)this._thumbcontent.push(a(b.content).find("[data-thumb]").attr("data-thumb"));else if(b.namespace&&this.owl._options.thumbs&&this.owl._options.thumbImage){var c=a(b.content).find("img");this._thumbcontent.push(c)}},this),"initialized.owl.carousel":a.proxy(function(a){a.namespace&&this.owl._options.thumbs&&(this.initialize(),this.currentslide(),this.draw())},this),"changed.owl.carousel":a.proxy(function(a){a.namespace&&"position"===a.property.name&&this.owl._options.thumbs&&(this.currentslide(),this.draw())},this),"refreshed.owl.carousel":a.proxy(function(a){a.namespace&&this._initialized&&this.draw()},this)},this.owl._options=a.extend(b.Defaults,this.owl.options),this.owl.$element.on(this._handlers)};b.Defaults={thumbs:!0,thumbImage:!1,thumbContainerClass:"owl-thumbs",thumbItemClass:"owl-thumb-item"},b.prototype.currentslide=function(){this.owl_currentitem=this.owl._current-this.owl._clones.length/2,this.owl_currentitem===this.owl._items.length&&(this.owl_currentitem=0)},b.prototype.draw=function(){a(this._thumbcontent._thumbcontainer).children().filter(".active").removeClass("active"),a(this._thumbcontent._thumbcontainer).children().eq(this.owl_currentitem).addClass("active")},b.prototype.initialize=function(){var b=this.owl._options;this._thumbcontent._thumbcontainer=a("<div>").addClass(b.thumbContainerClass).appendTo(this.$element);var c;if(this.owl._options.thumbImage)for(c=0;c<this._thumbcontent.length;++c)this._thumbcontent._thumbcontainer.append("<button class="+b.thumbItemClass+'><img src="'+this._thumbcontent[c].attr("src")+'" alt="'+this._thumbcontent[c].attr("alt")+'" /></button>');else for(c=0;c<this._thumbcontent.length;++c)this._thumbcontent._thumbcontainer.append("<button class="+b.thumbItemClass+">"+this._thumbcontent[c]+"</button>");a(this._thumbcontent._thumbcontainer).on("click","button",a.proxy(function(c){var d=a(c.target).parent().is(this._thumbcontent._thumbcontainer)?a(c.target).index():a(c.target).parent().index();c.preventDefault(),this.owl.to(d,b.dotsSpeed)},this))},b.prototype.destroy=function(){var a,b;for(a in this._handlers)this.owl.$element.off(a,this._handlers[a]);for(b in Object.getOwnPropertyNames(this))"function"!=typeof this[b]&&(this[b]=null)},a.fn.owlCarousel.Constructor.Plugins.Thumbs=b}(window.Zepto||window.jQuery,window,document);
</script>	
	<script>
	$(document).ready(function(){

$('.owl-carousel').owlCarousel({
   loop: true,
        items: 1,
        slideSpeed: 2000,
        autoplay: true,
        thumbs: true,
        thumbImage: true,
        thumbContainerClass: 'owl-thumbs row',
        thumbItemClass: ' col-md-3'
   });
   

 $('.wpcf7-form-control').on('input', function() {
  if (this.value.trim().length >= 1) {
    // call your function here
      console.log(jQuery("#product").length)
if(jQuery("#product").length==1){
 	jQuery("#product").val("<?php echo $brand_name ;?> - <?php echo get_the_title();?>")
	 console.log("PRODUCTNAME:"+jQuery("#product").val())
}	
  }
});
});
	</script>