<?php 
	get_header('brand');
	 	
 $term = get_queried_object();
	$banner_video = get_field( 'banner_video', $term ); 
	$template_color = get_field( 'template_color', $term ); 
	 if($template_color==""){
		 $cterm = get_term( $term->parent  );
		 $template_color = get_field( 'template_color',$cterm );
		 
	 }
	 
		$banner_image = get_field('banner_image' , $term );
		 
 ?>

<style>
.our-product-items h3::after , h3.product-name::after {
    content: '';
    position: absolute;
    bottom: -7px;
    left: 50%;
    width: 30%;
    height: 2px;
    background-color: <?php echo $template_color;?>;
    -webkit-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    transform: translateX(-50%);
}
.product-item h3 {
    color: #000;
    text-align: CENTER;
    font-size: 15px;
    position: relative;
}
h3.product-name{
	   color: #000;
    text-align: CENTER;
    font-size: 15px;
    position: relative;
}
.brand-header h1 {
    color: #000;
    margin-top: 50px;
}
.btn-primary {
    color: #000;
    background-color: <?php echo $template_color;?>;
    border-color: <?php echo $template_color;?>;
}
.product-image img {
    width: 100%;
}

.product-image {
    width: 100%;
    text-align: center;
    padding: 15px;
}
</style>
  <!-- Header Start -->
    <!-- Header Start -->
	<?php if($banner_video !=""){ ?>
	 <div class="banner">
            <video autoplay
                   style="width: 100%;"
                   loop
                   preload
                   data-setup='{"poster":"","autoplay":"muted","controls":false}'
                   muted>
                <source src="<?php echo $banner_video; ?>" type='video/mp4'>
            </video>
 
           
        </div>
	<?php } else { 
	if($term->parent!=0){
		
		
	?>
	
	  <div class="container-fluid   brand-header">
        <div class="container ">
            <div class="row  ">
                <div class="col-lg-10  ">
                    <h1 class="display-3 animated slideInDown"><?php echo strtoupper($term->name);?></h1>
                    
                </div>
            </div>
        </div>
    </div>
	<?php	
	}else{
		$show_banner_text = 1;
		?>
		<style>
		.page-header {
    background: linear-gradient(rgba(24, 29, 56, 0%), rgb(24 29 56 / 0%)), url(<?php echo $banner_image;?>) !important;
    position: Relative;
    /* background-position: center bottom !important; */
  
    /* width: 100%; */
    /* background-attachment: fixed !important; */
    /* margin-bottom: 0 !important; */
    background-size: cover !important;
    background-repeat: no-repeat !important;
    margin: 0 auto;
    display: block;
    background-position: center center !important;
}

/* Default height for desktop screens up to 1490px */
@media (max-width: 1490px) {
   .page-header {
        height: 300px;
    }
}

/* Height for screens wider than 1490px (above 1490px) */
@media (min-width: 1491px) {
    .page-header {
        height: 400px;
    }
}
		 </style>
		<?php
		if($banner_image==""){
			$banner_image = get_stylesheet_directory_uri()."/img/energy-banner.jpg";
		$show_banner_text = 0;
		
		?>
		<style>
		.page-header {
    background: linear-gradient(rgba(24, 29, 56, .7), rgb(24 29 56 / 46%)), url(<?php echo $banner_image;?>) !important;
    position: Relative;
    /* background-position: center bottom !important; */
      height: 300px;  
    /* width: 100%; */
    /* background-attachment: fixed !important; */
    /* margin-bottom: 0 !important; */
    background-size: cover !important;
    background-repeat: no-repeat !important;
  
    background-position: center center !important;
}
		 </style>
		<?php
		}
		
		?>
		
    <div class="container-fluid bg-primary py-5 mb-5 page-header"   >
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
				<?php if($show_banner_text=="0"){ ?>
                    <h1 class="display-3 text-white animated slideInDown"><?php echo strtoupper($term->name);?></h1>
                    <!---<nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url();?>">Home</a></li> 
                            <li class="breadcrumb-item text-white active" aria-current="page"><?php echo strtoupper($term->name);?></li>
                        </ol>
                    </nav>-->
				<?php } ?>
                </div>
            </div>
        </div>
    </div>
	
	<?php
	}
	} ?>
    <!-- Header End -->


     <!-- Categories Start -->
	 <?php if(get_field('about', 'brand_' . $term->term_id) !=""){ ?>
    <div class="container-xxl py-5 category">
        <div class="container">
            <div class="  wow fadeInUp" data-wow-delay="0.1s"> 
			<?php echo   get_field('about', 'brand_' . $term->term_id); ?>
            </div>  
        </div>
    </div>
	 <?php } ?>
    <!-- Categories Start -->

     <!-- Service Start -->
    <div class="container-xxl  "  >
        <div class="container"> 
            <div class="row g-4 our-product-items">
			 <?php 
			$brands =  get_terms([
			'taxonomy' => 'brand',
			'parent' => $term->term_id, 'orderby' => 'ID', 
			'hide_empty' => true,
		]); 
    if ( !empty( $brands ) && !is_wp_error( $brands ) ){
 
foreach($brands as $brand){
	 
 ?>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <a href="<?php echo get_term_link($brand->term_id) ;?>"><div class="product-item text-center pt-3"  hr>
                      
						<div class="product-image">
                            <img src="<?php echo   get_field('image', 'brand_' . $brand->term_id); ?>"  > 
                             
                         </div> 
                         <h3><?php echo $brand->name;?></h3>
						 
                        </div>
                       </a>
                    </div>
                
           
                 <?php } 
				 
	}else{
		 
						$args = array(	'post_type' => array('product'),
						'posts_per_page' => -1,  
						'post_parent'	=>0,
						'orderby'   => 'date',
						'order' => 'ASC', 
        'tax_query' => array(
            array(
                'taxonomy' => 'brand',
                'field' => 'term_id',
				'terms' => $term->term_id
            ),
        ),
						); 
						$loop = new WP_Query($args);
						$i=0; 
						if($loop->have_posts()) {
							$online=1;
							$show_paging = 0;

							while($loop->have_posts()) : $loop->the_post();
							 $productimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
								 $link = get_field('link');
                             if(get_field('link') == ""){
								 $link = get_permalink();
							 }
							?>
							 <div class="col-lg-3 col-sm-6 wow fadeInUp text-left" data-wow-delay="0.1s">
                    <a href="<?php echo $link;?>"  ><div class="product-item text-center pt-3"  hr>
                      
						<div class="product-image">
                            <img src="<?php echo   $productimage[0]; ?>"  > 
                             
                         </div> 
                         <h3 class="product-name"><?php echo get_the_title();?> <?php if(get_field('phase') !="") { ?>(<span><?php echo get_field('phase');?></span>)<?php } ?></h3>
                          <?php the_content();?> 
						 
                        </div>
                       </a>
                    </div>
							<?php
							endwhile;
							wp_reset_postdata(); 
						} 
	}
	
	?>
                 
                 
            
            </div>
        </div>
    </div>
   
  	<?php
	   
	get_footer();?>  