<?php 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?>
 <style>
 input.wpcf7-form-control.wpcf7-submit {
    color: #fff;
    background-color: rgb(118, 194, 27);
    border-color: rgb(118, 194, 27);
    width: 100%;
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
    border: 0px;
    font-family: 'Nunito', sans-serif;
    font-weight: 600;
    transition: .5s;
}

 input.wpcf7-form-control.wpcf7-submit:hover {
    color: #fff;
    background-color: #52565b;
    border-color: #52565b;
}
textarea.form-control {
    min-height: calc(1.5em + .75rem + 2px);
    height: 75px;
}

.note-img-box {
    width: 100px;
    height: 100px;
    /* background-image: url(your-image.jpg); */
    background-size: cover;
    background-position: center;
    clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
    border: 5px solid rgb(118,194,27);
    background: rgb(118,194,27);
    float:left;    
    margin-right: 15px;
}
.note-box p {
    line-height: 20px !important;
    height: 100px;
    display: flex
;
align-items:Center;justify-conetnt:center;
    margin: 0px;
}
ul.side-notes {
    padding: 0px;
    height: 100%;
}

.note-box {
    position: relative;
}
.note-box:before {
    position: absolute;
    content: ' ';
    /* background: #000; */
    width: calc(100% - 50px);
    height: 100%;
    margin-left: 50px;
    border: 1px solid #484a4b;
    border-top-right-radius: 50px;
    border-bottom-right-radius: 50px;
}

.note-box p {
    line-height: 20px !important;
    height: 100px;
    display: flex;
;
    align-items: Center;
    justify-conetnt: center;
    margin: 0px;
    font-size: 15px;
    padding-right: 15px;
}
ul.side-notes li{
    list-style:none;height:25%;
}

.side-notes {
    position: relative;
    height: 100%;
}
.note-img {
    width: 90px;
    height: 90px;
    position: relative; 
    background-size: cover !important;
    background-position: center !important;
    clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
}
textarea.wpcf7-form-control.wpcf7-textarea {
    height: 100px;
}
 .wpcf7-form-control {
    display: block;
    width: 100%;
    padding: .375rem .75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #52565b;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    appearance: none;
    border-radius: 0px;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
form.wpcf7-form label {
    display: block;
    width: 100%;
}
.wpcf7-form-control-wrap {
    position: relative;
    width: 100%;
    display: block;
}
.note-box {
    position: relative; 
}
img.wpcf7-form-control.wpcf7-captchac.wpcf7-captcha-captcha-1 {
    width: 100px;
    height: 38px;
}
img.wpcf7-form-control.wpcf7-captchac.wpcf7-captcha-captcha-1 {
    float: left;height:40px;
}
input.wpcf7-form-control.wpcf7-captchar {
    width: auto;
}
.enquiry-form {
    padding-left: 70px;
}
ul.side-note{
    position:relative ;
}
ul.side-notes:before {
    content: ' ';
    background: #76c21b;
    height: calc(100% - 100px);
    position: absolute;
    width: 5px;
    left: 47px;
}
@media (max-width: 800px){
    .enquiry-form {
    padding-left: unset;
}
ul.side-notes li {
    list-style: none;
    height: 25%;
    padding: 10px 0;
}
ul.side-notes:before { 
    top: 50px;
}

.page-header .py-5{
    
}
}
 </style>
  <!-- Header Start -->
    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Project Enquiry</h1>
                <!---    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url();?>">Home</a></li>
                             <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Contact Start -->
     <div class="container-xxl py-5">
        <div class="container"> 
            <div class="row g-4 our-service-items">
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s"> 
                <ul class="side-notes">
                    <?php 
                    
                    						 
		 
                    ?>
                    <li>
                        
                        <div class="note-box"><div class="note-img-box"> <div class="note-img" style="background:url(<?php echo get_field("side_note_image_1");?>)"></div></div><?php echo get_field("side_note_1");?></div>
                    </li>
                    <li>
                        
                        <div class="note-box"><div class="note-img-box"> <div class="note-img" style="background:url(<?php echo get_field("side_note_image_2");?>)"></div></div><?php echo get_field("side_note_2");?></div>
                    </li>
                    <li>
                        
                        <div class="note-box"><div class="note-img-box"> <div class="note-img" style="background:url(<?php echo get_field("side_note_image_3");?>)"></div></div><?php echo get_field("side_note_3");?></div>
                    </li>
                    <li>
                        
                        <div class="note-box"><div class="note-img-box"> <div class="note-img" style="background:url(<?php echo get_field("side_note_image_4");?>)"></div></div><?php echo get_field("side_note_4");?></div>
                    </li>
                    
                    </ul>
                
                </div> 

      
                <div class="col-lg-8 col-md-12 wow fadeInUp" data-wow-delay="0.5s"><div class="enquiry-form">
                  <?php echo do_shortcode('[contact-form-7 id="438d418" title="Project Enquiry"]');?></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->


   
	<?php
	 
	endwhile;  
	get_footer();?>  