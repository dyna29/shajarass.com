 
<!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer    wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row  ">
                <div class="col-lg-3 col-md-6">
                   <a href="<?php echo site_url();?>" class="footer-logo">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/logo-footer.png">
        </a>  <a class="social-linkedin" href="https://www.linkedin.com/company/shajara-sustainable-solutions-3s/" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/linked-in.png"></a>
                   
                </div>
                <div class="col-lg-9 left-footer">
				      <div class="row  ">
                <div class="col-lg-12">
				<ul class="footer-menu">
                  <li>  <a class="btn btn-link" href="<?php echo site_url();?>">Home</a></li>
                  <li>  <a class="btn btn-link" href="<?php echo site_url('about');?>">About Us</a></li>
                  <li>  <a class="btn btn-link" href="<?php echo site_url('services');?>">Services</a></li>
                  <li>  <a class="btn btn-link" href="<?php echo site_url('products');?>">Products</a></li>
                <!--  <li>  <a class="btn btn-link" href="<?php echo site_url('our-partners');?>">Our Partners</a></li>-->
                    <li><a class="btn btn-link" href="<?php echo site_url('contact');?>">Contact Us</a></li> 
                 </ul>     
                </div>
                </div>
				      <div class="row  ">
                <div class="col-lg-12">
                   <ul class="footer-locate-menu">
                  <li>  <p class="mb-2"><a class="" href="https://goo.gl/maps/eukFJbLPfvsnx3WH7?coh=178573&entry=tt" target="_blank"><i class="fa fa-map-marker-alt me-2"></i><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons8-kuwait-48.png">Shajara Sustainability Solutions (3S) - Kuwait<br>11th floor, Albudor Altejaria Tower, Ahmad Al Jaber St, Kuwait City, Kuwait</a> </p></li> 
                      <li> <p class="mb-2 inline-a"><a class="" href="tel: +965 22406044"><i class="fa fa-phone-alt me-2"></i>+965 22406044</a>  
					  <a class="" href="mailto:info@alshajara.com"><i class="fa fa-envelope me-2"></i>info@alshajara.com</a> 
					 </p>
                   </li> 
                  <li>  <p class="mb-2"><a class="" href="https://maps.app.goo.gl/UCre6mHCthHnQqz98" target="_blank"><i class="fa fa-map-marker-alt me-2"></i><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/icons8-qatar-48.png">Shajara Sustainability Solutions (3S) - Qatar<br> Level 21, Doha Tower, West Bay, Doha, Qatar </a> </p></li> 
                      <li class="newline "> <p class="mb-2 inline-a "><a class="" href="tel: +974 40316673"><i class="fa fa-phone-alt me-2"></i>+974 40316673</a>  
					    <a class="" href="mailto:info@alshajara.com"><i class="fa fa-envelope me-2"></i>info@alshajara.com</a> 
 
					 </p>
                   </li> 
                 </ul>   
                 
                      
                </div>
                </div>
                </div>
               
            
            </div>
        </div>
        </div>
        <!--<div class="container-fluid footermap">
		
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d890603.0788230407!2d47.535719949999994!3d29.314072799999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fc5363fbeea51a1%3A0x74726bcd92d8edd2!2sKuwait!5e0!3m2!1sen!2sin!4v1667998266071!5m2!1sen!2sin"
                        frameborder="0" width="100%"style="min-height: 200px; border:0;" allowfullscreen="" aria-hidden="false"
                        tabindex="0"></iframe>
		</div>-->
		<div class="container-fluid bg-dark text-light footer  wow fadeIn" data-wow-delay="0.1s">
    
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-12 text-center   mb-3 mb-md-0">
                        &copy; <?php echo date('Y'); ?> <a class=" " href="#" style="text-decoration:none;">Sharaja Sustainability Solutions</a>, All Right Reserved.

                       
                    </div>
                     
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
	<div class= "btn btn-lg btn-primary btn-lg-square back-to-prev"><i class="bi bi-arrow-left"></i></div>
    <!-- JavaScript Libraries -->
 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/lib/wow/wow.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/lib/easing/easing.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/main.js?v=3"></script>
	  <script>
            $(document).ready(function() {
				
				
			 
$(".back-to-prev").click(function(){
 history.back()
});
              var owl = $('#our-partners');
              owl.owlCarousel({
                items: 4,
                loop: true,
                margin: 30,
    nav: false,
                autoplay: true,
                autoplayTimeout: 1000,
                autoplayHoverPause: true,
    responsiveClass: true,  responsive: {
        0: {
            items: 1,
        },
        600: {
            items: 1
        },
        1200: {
            items: 4
        }
    }
              });
              $('.play').on('click', function() {
                owl.trigger('play.owl.autoplay', [1000])
              })
              $('.stop').on('click', function() {
                owl.trigger('stop.owl.autoplay')
              })
			  
			  
			  
			     var owl2 = $('#our-clients');
              owl2.owlCarousel({
                items: 4,
                loop: true,
                margin: 30,
    nav: false,
                autoplay: true,
                autoplayTimeout: 1000,
                autoplayHoverPause: true,
    responsiveClass: true,  responsive: {
        0: {
            items: 1,
        },
        600: {
            items: 1
        },
        1200: {
            items: 4
        }
    }
              });
              $('.play').on('click', function() {
                owl2.trigger('play.owl.autoplay', [1000])
              })
              $('.stop').on('click', function() {
                owl2.trigger('stop.owl.autoplay')
              })
			  
			  
			  
			  var owl = $('.screenshot_slider').owlCarousel({
    loop: true,
    responsiveClass: true,
    nav: true,
    margin:  0,    
   
                autoplay: true,
                autoplayTimeout: 3000,
    smartSpeed: 400,
    center: true,
    navText: ['<i class="bi bi-chevron-left"></i>', '<i class="bi bi-chevron-right"></i>'],
    responsive: {
        0: {
            items: 1,
        },
        600: {
            items: 1
        },
        1200: {
            items: 3
        }
    }
});

/****************************/

jQuery(document.documentElement).keydown(function (event) {    

    // var owl = jQuery("#carousel");

    // handle cursor keys
    if (event.keyCode == 37) {
       // go left
      owl.trigger('prev.owl.carousel', [400]);
      //owl.trigger('owl.prev');
    } else if (event.keyCode == 39) {
       // go right
        owl.trigger('next.owl.carousel', [400]);
       //owl.trigger('owl.next');
    }

});
           

	$.fn.countTo = function (options) {
		options = options || {};
		
		return $(this).each(function () {
			// set options for current element
			var settings = $.extend({}, $.fn.countTo.defaults, {
				from:            $(this).data('from'),
				to:              $(this).data('to'),
				speed:           $(this).data('speed'),
				refreshInterval: $(this).data('refresh-interval'),
				decimals:        $(this).data('decimals')
			}, options);
			
			// how many times to update the value, and how much to increment the value on each update
			var loops = Math.ceil(settings.speed / settings.refreshInterval),
				increment = (settings.to - settings.from) / loops;
			
			// references & variables that will change with each update
			var self = this,
				$self = $(this),
				loopCount = 0,
				value = settings.from,
				data = $self.data('countTo') || {};
			
			$self.data('countTo', data);
			
			// if an existing interval can be found, clear it first
			if (data.interval) {
				clearInterval(data.interval);
			}
			data.interval = setInterval(updateTimer, settings.refreshInterval);
			
			// initialize the element with the starting value
			render(value);
			
			function updateTimer() {
				value += increment;
				loopCount++;
				
				render(value);
				
				if (typeof(settings.onUpdate) == 'function') {
					settings.onUpdate.call(self, value);
				}
				
				if (loopCount >= loops) {
					// remove the interval
					$self.removeData('countTo');
					clearInterval(data.interval);
					value = settings.to;
					
					if (typeof(settings.onComplete) == 'function') {
						settings.onComplete.call(self, value);
					}
				}
			}
			
			function render(value) {
				var formattedValue = settings.formatter.call(self, value, settings);
				$self.html(formattedValue);
			}
		});
	};
	
	$.fn.countTo.defaults = {
		from: 0,               // the number the element should start at
		to: 0,                 // the number the element should end at
		speed: 1000,           // how long it should take to count between the target numbers
		refreshInterval: 100,  // how often the element should be updated
		decimals: 0,           // the number of decimal places to show
		formatter: formatter,  // handler for formatting the value before rendering
		onUpdate: null,        // callback method for every time the element is updated
		onComplete: null       // callback method for when the element finishes updating
	};
	
	function formatter(value, settings) {
		return value.toFixed(settings.decimals);
	}
		   })
			
 

jQuery(function ($) {
  // custom formatting example
  $('.count-number').data('countToOptions', {
	formatter: function (value, options) {
	  return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
	}
  });
  
  // start all the timers
  $('.timer').each(count);  
  
  function count(options) {
	var $this = $(this);
	options = $.extend({}, options || {}, $this.data('countToOptions') || {});
	$this.countTo(options);
  }
});
          </script>
 
 
<?php wp_footer();?> 
</body>


</html>
  

 
 