<?php
	/*
	*Template Name: Home Template
	*/ 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?> 
<style>
.eapps-widget-toolbar {
    display: none;
}
.view-gallery {
    height: auto;
    line-height: 5px;
    padding: 10px !important;
    padding: 20px 15px !important;
    font-size: 18px;
    display: block;
    background-color: rgb(118, 194, 27);
    border-color: rgb(118, 194, 27);
    width: 200px;
    color: #fff;
    margin: 0 auto;
    text-align: CENTER;
    margin-top: 30px;
    border-radius: 25px;
}
a.view-gallery:hover {
    background: grey;
    color: #fff;
}
	.header-carousel video {
    /* height: 498px; */
    width: 100vw!important;
    /* position: fixed; */
    right: 0;
    bottom: 0;
    /* min-width: 100%; */
    /* min-height: 498px; */   
}
.video-container {
   /*  height: calc(70vh - 75px); */
    overflow: hidden;
    width: 100% !important;
}
body {
    background: #eee;
    width: 100vw;
    overflow-x: hidden !important;
}
.image-background{
	background-size:cover !important;
	background-position:center center !important;
	widht:100%;
	height: calc(95vh - 75px);
}
.magnific-img,.video-box {
    width: 25%;
    float: left;
    padding: 3px;
}.magnific-img img {
    width: 100%;
}
.home-gallery{
	 background: #eeeeee; 
}
@media (max-width: 477px){
 .magnific-img, .video-box {
    width: 100%;
    float: left;
    padding: 3px;
}
.image-background{
	height: 300px !important;
}
.video-container video{
     width: 100%!important;
    height: 300px;
    margin-top: 0px;
    background: #ed8211;
}
}
	</style>
  <!-- Carousel Start -->
    <div class="container-fluid p-0 ">
        <div class="owl-carousel header-carousel position-relative">
		
		 <?php  
	 
							 
			while ( have_rows('slider') ) : the_row();
			$slider_type = get_sub_field('slide_type');
			 $desktop_image__video = get_sub_field('desktop_image__video');
			 $mobile_image__video = get_sub_field('mobile_image__video');
			 $mobile_image__video_gif = get_sub_field('mobile_image__video_gif');
			 $mobile_image__video_mp4 = get_sub_field('mobile_image__video_mp4');
			 $mobile_image__video_webp = get_sub_field('mobile_image__video_webp');
			 $caption_1 = get_sub_field('caption_1');
			 $caption_2 = get_sub_field('caption_2');
			 $link = get_sub_field('link');
			 ?>
            <div class="owl-carousel-item item-desktop position-relative">
			<?php  
			 if($slider_type =='Video'){
				
				 ?>
			<div class="video-container">
                	<video class="header-video"  preload="auto" autoplay="" loop="" muted="" webkit-playsinline="" playsinline="">
    <source src="<?php echo $desktop_image__video; ?>" type="video/mp4">
    	Your browser does not support the video tag.
	</video></div>
	<?php }else{ ?>
	 <div class="image-background" style="background:url('<?php echo $desktop_image__video; ?>" alt=""></div>
	   <?php }  ?>
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" >
			 <?php if($caption_1 !=""){ ?>
			 <div class="caption-container">
				<div id="corner"></div>
				<h2><?php echo $caption_1;?></h2>
				<hr>
				 <p> <a href="<?php echo $link;?>" class="btn btn-primary py-3 px-5 mt-2">Read More</a></p>
				</div> 
                    
				<?php } ?> 
                </div>
            </div>
            <div class="owl-carousel-item item-mobile position-relative">
			<?php  
			 if($slider_type =='Video'){
				
				 ?>
			<div class="video-container">
                	<video class="header-video"  preload="auto" autoplay="" loop="" muted="" webkit-playsinline="" playsinline="">
    <source src="<?php echo $mobile_image__video; ?>" type="video/mp4"  onerror="fallback(parentNode)">
	<img decoding="async" src="<?php echo $mobile_image__video_gif;?>">
    	Your browser does not support the video tag.
	</video></div>
	<?php }else{ ?>
	 <div class="image-background" style="background:url('<?php echo $mobile_image__video; ?>" alt=""></div>
	   <?php }  ?>
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" >
				<?php if($caption_1 !=""){ ?>
			 <div class="caption-container">
				<div id="corner"></div>
				<h2><?php echo $caption_1;?></h2>
				<hr>
				 <p> <a href="<?php echo $link;?>" class="btn btn-primary py-3 px-5 mt-2">Read More</a></p>
				</div> 
				<?php } ?> 
                </div>
            </div>
			   <?php endwhile;
			   
			    $args = array(
    'posts_per_page' => 1, // we need only the latest post, so get that post only
    'cat' =>  16 , // Use the category id, can also replace with category_name which uses category slug
    //'category_name' => 'SLUG OF FOO CATEGORY,
		'orderby'   => 'ID',
						'order' => 'DESC',
); 

 $loop = new WP_Query($args);
						$i=0; 
						if($loop->have_posts()) {
							
							while($loop->have_posts()) : $loop->the_post();
										$featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );    ?>
									 <div class="owl-carousel-item item-desktop position-relative">
			 
	 <div class="image-background" style="background:url('<?php echo $featuredimage[0]; ?>" alt=""></div>
	    
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" >
			 <div class="caption-container">
				<div id="corner"></div>
				<h2><?php echo get_the_title();?></h2>
				<hr>
				 <p> <a href="<?php echo get_permalink();?>" class="btn btn-primary py-3 px-5 mt-2">Read More</a></p>
				</div> 
                    
                </div>
            </div>
            <div class="owl-carousel-item item-mobile position-relative">
		 
	 <div class="image-background" style="background:url('<?php echo $featuredimage[0]; ?>" alt=""></div>
	   
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" >
			 <div class="caption-container">
				<div id="corner"></div>
				<h2><?php echo get_the_title();?></h2>
				<hr>
				 <p> <a href="<?php echo get_permalink();?>" class="btn btn-primary py-3 px-5 mt-2">Read More</a></p>
				</div> 
                    
                </div>
            </div>
									 <?php
							endwhile;
							wp_reset_postdata(); 
						}  
			?>
          
			
        </div>
    </div>
    <!-- Carousel End -->


    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
		<h5 class="sub-title">Our <span>Service</span></h5>
		    <h1 class="mb-4 text-center ">What we offer</h1>
            <div class="row g-4 our-service-items">
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item text-center pt-3" >
                      
						<div class="service-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/holding-box-white.png" class="icon-white" > 
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/holding-box-color.png" class="icon-color" > 
                         </div> 
                        <div class="p">  <h3>Products provider</h3>
							<p>3S provides variety of sustainable solutions products from world rennin equipment providers!</p>
							
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item text-center pt-3"  >
                         
						<div class="service-icon">
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-flash-on-80-2.png" class="icon-white" > 
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-flash-on-80-1.png" class="icon-color" > 
                         </div>  
                        <div class="p"> 
                            <h3>Energy solutions</h3>
							<p>Complete packages of variety of complete energy solutions that start from finding what suites the clients need</p>
                        </div>
                         
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item text-center pt-3 last-child "  >
                         <div class="service-icon">
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-consultation-80-1.png" class="icon-white" > 
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-consultation-80.png" class="icon-color" > 
                         </div>  
                        <div class="p"> 
                            <h3>Consultancy</h3>
							<p>Technical design, tender preparation, ESG support, …etc.
</p>
                       
                        </div>
                    </div>
                </div>
            
            </div>
        </div>
    </div>
    <!-- Service End -->

    <!-- About Start -->
    <div class="container-fluid  py-5  bg-white about-us-section">
        <div class="container"> 
            <div class="row  ">
			
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    	<h5 class="sub-title left">About <span>Us</span></h5>
		    <h1 class="mb-4  left ">Who we are</h1>
                    <p class="mb-4">"Shajara Sustainability Solutions (3S) is sustainable energy products and service provider that was established in 2022 in
 Kuwait with focus on providing their services through out the world. 3S is a subsidiary of Al-Shajara holding, which was established in 1978 with focus on developing variety of business in the Middle East region."
</p>
                     
                    <a  class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="<?php echo site_url('about');?>">Read More</a>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="<?php echo get_stylesheet_directory_uri(); ?>/img/about-image.jpg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                </div>
			<!--	<div class="row  ">
                <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s"  >
                   <div class="counter-block">
 <div class="row text-center">
	        <div class="col">
	        <div class="counter">
      <i class="fa fa-code fa-2x"></i>
      <h2 class="timer count-title count-number" data-to="100" data-speed="1500"></h2>
       <p class="count-text ">Our Customer</p>
    </div>
	        </div>
           
              <div class="col">
                  <div class="counter">
      <i class="fa fa-lightbulb  fa-2x"></i>
      <h2 class="timer count-title count-number" data-to="11900" data-speed="1500"></h2>
      <p class="count-text ">Project Complete</p>
    </div></div>
              <div class="col">
              <div class="counter">
      <i class="fa fa-bug fa-2x"></i>
      <h2 class="timer count-title count-number" data-to="157" data-speed="12"></h2>
      <p class="count-text ">Partners</p>
    </div>
              </div>
           
         </div>
</div>
                </div>
            </div>-->
        </div>
    </div>
    <!-- About End -->

    <!-- About Start -->
    <div class="container-xxl py-5 founder-section">
        <div class="container">
            <div class="row ">
               <!-- <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                    <div class="message-img">
			 <div class="message-img-1" style="background:url(<?php echo get_stylesheet_directory_uri(); ?>/img/ceo-dr-ameer.jpg)"></div>
                
                  </div>
                  </div>
                </div>-->
                <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.3s">
              <div class="message-block">
               	<h5 class="sub-title  ">CEO <span>Message</span></h5>
		   <!-- <h1 class="mb-4  left ">From the CEO</h1>-->
                    <p class="founder-message">
					"Sustainability is not any more part of the social responsibility or a commodity that only some people can have access to, it’s the way to save the planet!"<br><br>
<?php /* <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/ameer_signature.png"class="founder-name"> */?>
 
					</p>
                   
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->
    
  
   <div class="l-feeds">
  <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
<div class="elfsight-app-7f1977eb-13d7-4ae2-908c-55c075766e55" data-elfsight-app-lazy></div>
  </div> 
   <?php if(get_field("enable_news")=="Yes"){ ?>  
    <!-- About Start -->
<div class="container-xxl py-5  ">
   <div class="container">
      <div class="row ">
         <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
            <!-- Courses Start -->
            <style>
            .carousel-container {
    position: relative;
}
               .owl-carousel .item {
               /* background: #3498db; */
               /* color: white; */
               padding: 0;
               text-align: center;
               font-size: 15px;
               border-radius: 10px;
               margin: 10px;
               }
               .nav-button {
               position: absolute;
               top: 50%;
               transform: translateY(-50%);
               background: rgb(255 255 255 / 64%);
               color: rgb(0 0 0);
               border: none;
               padding: 15px;
               font-size: 20px;
               cursor: pointer;
               border-radius: 50%;
               z-index: 100;
               }
               .nav-button:hover {
               background: rgb(255 255 255);
               }
               #prev {
               left: 150px;
               }
               #next {
               right: 150px;
               }
               .news-thumb {
               height: 250px;
               background-size: cover !important;
               background-position: center center !important;
               width: 100%;
               }
               h3.news-title {
               font-size: 16px;
               padding:10px 10px;
               height:70px;text-align:left;
               }
               .news-excerpt{
               text-align:left;
               padding:10px 10px;
               }
               /* Second Carousel Styles */
               .image-slider-container {
               margin: auto;
               text-align: center;
               }
               .main-slider .item img {
               width: 100%;
               border-radius: 10px;
               }
               .thumbnail-slider .item img {
               width: 100px;
               height: 60px;
               object-fit: cover;
               cursor: pointer;
               border: 2px solid transparent;
               border-radius: 5px;
               }
               .thumbnail-slider .item img:hover, .thumbnail-slider .item.active img {
               border: 2px solid #3498db;
               }
               .detailed-news-container {
               position: fixed;
               top: 0px;
               left: 0px;
               background: #0000004a;
               z-index: 99999999;
               height: 100vh;
               display: none
               ;
               align-items: center;
               justify-content: center;width: 100%;
               }
               .detailed-news {
               width: 80%;
               background: #fff;
               padding: 30px;
               position: relative;
               }
               .detailed-news-container.active {
               display: flex;
               }
               .news-box {
               cursor: pointer;
               }
               .news-box {
               cursor: pointer;
               transition: .5s;
               border: 1px solid rgb(82 86 91 / 21%);
               }
               .news-box:hover {
               margin-top: -10px;
               background: #76c21b;
               }
               a.close-news {
               position: absolute;
               right: -10px;
               color: #000;
               font-size: 20px;
               top: -10px;
               background: #e7e0e0;
               /* padding: 5px 10px; */
               border-radius: 57px;
               width: 30px;
               height: 30px;
               display: flex
               ;
               align-items: center;
               justify-content: center;
               }
               h5.news-title {
    text-align: left;
    margin-left: 10px;
    text-transform: uppercase;
    font-size: 11px;
}
            </style>
            <div class="carousel-container">
               <button id="prev" class="nav-button">←</button>
               <div class="owl-carousel owl-theme" id="news-slider">
                  <?php
                     $args = array(	'post_type' => array('news'),
                     'posts_per_page' => -1,  
                     'post_parent'	=>0,
                     'orderby'   => 'id',
                     'order' => 'ASC',
                     'orderby'   => 'ID', 
                       
                     ); 
                     $loop = new WP_Query($args);
                     $i=0; 
                     if($loop->have_posts()) {
                     $online=1;
                     $show_paging = 0;
                     
                     while($loop->have_posts()) : $loop->the_post();
                      $newsimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
                     
                     ?>
                  <div class="item">
                     <div class="news-box"  boxid = "<?php echo get_the_id();?>">
                        <div class="news-thumb" style="background:url(<?php echo $newsimage[0];?>)"></div>
                        <h3 class="news-title"><?php echo get_the_title();?></h3><h5 class="news-title"><?php echo get_field('news_date');?></h5>
                        <div class="news-excerpt"><?php echo substr(strip_tags(get_the_content()),0,50);?>....</div>
                     </div>
                  </div>
                  <?php
                     endwhile;
                     wp_reset_postdata(); 
                     } 
                     ?>
               </div>
               <button id="next" class="nav-button">→</button>
            </div>
            <?php
               $args = array(	'post_type' => array('news'),
               'posts_per_page' => -1,  
               'post_parent'	=>0,
               'orderby'   => 'id',
               'order' => 'ASC',
               'orderby'   => 'ID', 
                 
               ); 
               $loop = new WP_Query($args);
               $i=0; 
               if($loop->have_posts()) {
               $online=1;
               $show_paging = 0;
               
               while($loop->have_posts()) : $loop->the_post();
                $newsimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
               
               ?>
            <div class="detailed-news-container detailed-news-container-<?php echo get_the_id();?>">
               <div class="detailed-news">
                  <a href="javascript:void())" boxid = "<?php echo get_the_id();?>" class="close-news">x</a>
                  <div class="row ">
                     <div class="col-lg-6" >
                         <style>
 
/* Main Gallery Layout */
.gallery {
    max-width: 600px;
    margin: auto;
    text-align: center;
}

/* Big Display Area */
.big-display img {
    width: 100%;
    height: auto;
    max-height: 350px;
    object-fit: cover;
    border-radius: 8px;
    border: 2px solid #ccc;
}

/* Thumbnail Scrollable Area */
.thumbnail-container {
    overflow-x: auto;
    padding: 10px;
    background: #fff;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(128, 128, 128, 0.25); 
}
.thumbnails::-webkit-scrollbar {
  height: 5px;
}

/* Track */
.thumbnails::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey; 
  border-radius:  0px;
}
 
/* Handle */
.thumbnails::-webkit-scrollbar-thumb {
  background: #000; 
  border-radius: 0px;
}

/* Handle on hover */
.thumbnails::-webkit-scrollbar-thumb:hover {
  background: #76c21b; 
}
/* Thumbnails Wrapper - Using CSS Grid */
.thumbnails {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    grid-auto-flow: column;
    gap: 10px;
    overflow-x: auto;
    scroll-snap-type: x mandatory;
}

/* Individual Thumbnails */
.news-thumb-box {
    width: 100px;
    height: 70px;
    border: 2px solid transparent;
    cursor: pointer; 
    overflow: hidden;
    transition: border 0.3s ease;
    scroll-snap-align: start;  width: 100px;
}
 
video  {
    width: 100%;
}
.big-preview {
    text-align: center;
    margin-bottom: 15px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(128, 128, 128, 0.25);
    padding: 10px;
}
.news-slider-thumb {
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: center;
}

/* Active Thumbnail */
.news-thumb-box.active {
    border: 2px solid #76c21b !important;
}
 
/* Hide scrollbar for cleaner look */
.thumbnail-container::-webkit-scrollbar {
    display: none;
}
.news-sldier-thumb{
	    height: 70px;
    background-size: cover !important;
    background-position: center center !important;
    width: 100%;
}
.main-media {
    width: 100%;
    height: 350px;
    background-size: cover !important;
    background-position: center center !important;
    background-repeat: no-repeat !important;
}
</style>
 

<div class="gallery-container">
    <!-- Big Display Area -->
    <div class="big-preview">
        <img src="https://via.placeholder.com/800x450" id="mainMedia-<?php echo get_the_id();?>" alt="Main Preview">
    </div>

    <!-- Thumbnails -->
    <div class="thumbnail-container">
        <div class="thumbnails">
           
             <?php	
$i = 0;
			 while ( have_rows('images') ) : the_row();
$i++;
$image = get_sub_field('image');
$image_url = wp_get_attachment_image_url( $image, 'gallery-thumb-btn' );
$image_url2 = wp_get_attachment_image_url( $image, 'full' );
if($i==1){
	$initiateclass="initiate-first";
}else{
	$initiateclass="";
}
 ?> 
   <div class="thumb-<?php echo get_the_id();?> news-thumb-box  <?php echo $initiateclass;?>" data-type="image" data-src="<?php echo $image_url2;?>"  >
                <div style="background:url(<?php echo $image_url;?>)" class="news-sldier-thumb"></div>
            </div>
 <?php
  endwhile;
  
  ?>
  
             <?php	
 
			 while ( have_rows('videos') ) : the_row();
$i++;
$image = get_sub_field('video');
$thumbnail = get_sub_field('thumbnail');
$image_url = wp_get_attachment_image_url( $thumbnail, 'gallery-thumb-btn' ); 
if($i==1){
	$initiateclass="initiate-first";
}else{
	$initiateclass="";
}
 ?> 
   <div class="thumb-<?php echo get_the_id();?> news-thumb-box <?php echo $initiateclass;?>" data-type="video" data-src="<?php echo $image;?>"  >
                <div style="background:url(<?php echo $image_url;?>)" class="news-sldier-thumb"></div>
            </div>
 <?php
  endwhile;
  
  ?>
        </div>
    </div>
</div>

 

<script>
$(document).ready(function () {
    $(".thumb-<?php echo get_the_id();?>").click(function () {
        let type = $(this).data("type");
        let src = $(this).data("src");

        // Remove active class from all and add to clicked
        $(".thumb-<?php echo get_the_id();?>").removeClass("active");
        $(this).addClass("active");

        if (type === "image") {
            $("#mainMedia-<?php echo get_the_id();?>").replaceWith(`<div class="main-media" style="background:url(${src})" id="mainMedia-<?php echo get_the_id();?>" alt="Main Preview"></div>`);
        } else if (type === "video") {
            $("#mainMedia-<?php echo get_the_id();?>").replaceWith(`
                <video id="mainMedia-<?php echo get_the_id();?>" controls autoplay>
                    <source src="${src}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            `);
        }
    });
});

</script>
                     </div>
                     <div class="col-lg-6" >
                        <h3 class="news-title"><?php echo get_the_title();?></h3>
                        <div class="full-news"><?php echo get_the_content();?></div>
                     </div>
                  </div>
               </div>
            </div>
            <?php
               endwhile;
               wp_reset_postdata(); 
               } 
               ?>
         </div>
      </div>
   </div>
</div>
<!-- About Start -->
<style>
ul.team-container li {
    display: inline-block;
    width: 33.33%;
    margin-bottom: 30px;
}
ul.team-container {
    padding: 0px;
}
.team-pic {
    background-size: cover !important;
    background-position: center center !important;
    width: 100%;
    height: 400px;    
}
.team-member {
    position: relative;
}
.team-info {
    position: absolute;
    bottom: 0px;
    left: 0px;
    height: 100%;
    width: 100%;
    background: rgb(0 0 0 / 56%);
    padding: 15px;
	top:calc(400px - 80px);
	transition:all 600ms ease-in-out;
}
.team-member {
    position: relative;
    overflow: hidden;
}
 
.team-content {
    color: #fff;
    font-size: 14px;
}
.team-title{
	height:80px;
}

.team-title h3 {
    height: 30px;
    color: #fff;
}
.team-title h4 {
    height: 30px;
    color: #fff;
    font-size: 18px;
}
.team-member:hover .team-info {
    top: 200px;
}

#prev {
    left: 30px;
    top: 35%;
}

#next {
    right: 30px;
    top: 35%;
}


@media (max-width: 800px){
.detailed-news-container {
    position: fixed;
    top: 10vh;
    left: 0px;
    background: #0000004a;
    z-index: 99999999;
    height: 80vh;
    display: none;
    align-items: center;
    justify-content: center;
    width: 100%;
}	
	ul.team-container li { 
    width:100%; 
}
.full-news {
    overflow-y: scroll;
    height: 30vh;
}

    .main-media {
        height: 250px;
    }
 
.detailed-news { 
    padding: 15px; 
}
h3.news-title {
    font-size: 16px;
    padding: 10px 0px;
    height: 70px;
    text-align: left;
}
.detailed-news {
    width: 90%; 
}

}
</style>
<?php } ?>
    <!-- Courses Start -->
	<style>
	body{
	background: #eee;
}
.section-padding{
	width:1170px;
	margin: 0 auto;
	padding:80px 0;
}

.owl-item .item {
   transform: translate3d(0, 0, 0); /* DO NOT REMEMBER WHERE TU PUT THIS, SEARCH FOR 3D ACCELERATION */
  // transform: scale(0.9);

  // transition: all .25s ease-in-out;  
 }

.screenshot_slider .owl-item .item .product-item {
background:#fff;
    -webkit-transition: 0.3s;
    -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    -o-transition: 0.3s;
    transition: 0.3s;
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
}

.screenshot_slider .owl-item.center .item .product-item {
    -webkit-transform: scale(1.50);
    -ms-transform: scale(1.50);
    transform: scale(1.50); 
}

.owl-carousel.screenshot_slider  .owl-stage-outer {
   overflow-y:unset !important;
    height: 350px;
}
.screenshot_slider .owl-nav {
    text-align: center;
    // margin: 40px 0;
}
.product-item-pad {
    width: 100%;
    padding: 30px;
}
.screenshot_slider .owl-nav button {
	font-size: 24px !important;
	margin: 10px;
	color: #033aff !important;
}
	</style>
    <div class="container-xxl py-5 products-section" >
		<video playsinline autoplay muted loop>
    <source src="<?php echo get_stylesheet_directory_uri(); ?>/img/v4.mp4" type="video/webm">
    	Your browser does not support the video tag.
	</video>
    <div class="videoContainerTxt">
        <div class="container">
            
          
                 <h5 class="sub-title  ">Our <span>Products</span></h5>
		    <h1 class="mb-4   text-center ">What we offer</h1>
            
	 <div class="screenshot_slider owl-carousel">
	<?php // WP_Query to get featured products
$args = array(
    'post_type' => 'product',    // Custom post type for products
    'posts_per_page' => -1,      // Get all matching products
    'meta_query' => array(
        array(
            'key'     => 'featured',    // Custom field name (ACF)
            'value'   => 'Yes',         // Featured product is set to "Yes"
            'compare' => '=',           // Match exactly
        )
    )
);

$featured_products = new WP_Query($args);

// Start the loop
if ($featured_products->have_posts()) :
    while ($featured_products->have_posts()) : $featured_products->the_post();
        
        // Get the product ID
        $product_id = get_the_ID();
         $product_image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'full' ); 
        // Get the brand taxonomy terms associated with the product
        $brand_terms = wp_get_post_terms($product_id, 'brand'); // Replace 'brand' with your taxonomy name
        
        if (!empty($brand_terms) && !is_wp_error($brand_terms)) {
			
			foreach($brand_terms as $brand_term){
				// Get the first brand term (assuming only one brand term per product)
			 
			 
			 
				
				// Get brand details
				
				if($brand_term->parent==0){
					$brand_slug = $brand_term->slug;
					$brand_name = $brand_term->name;
					// Get the ACF image for the brand term (assuming 'brand_image' is the ACF field name for the image)
					$brand_image = get_field('image', 'brand_' . $brand_term->term_id); // ACF field for image
				}else{
					$child_brand = $brand_term->name;
				}
			}
               }
            ?>
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			  <a   style="border-radius: 30px;" href="<?php echo get_permalink();?>"><img src="<?php echo $product_image[0]; ?>" alt="" title=""></a>
			 </div>
		 <div class="description">
			 <a  class="brand-link" style="border-radius: 30px;" href="<?php echo site_url('brand')."/".$brand_slug;?>"><img src="<?php echo $brand_image; ?>"></a>
			 <h4><?php echo get_the_title();?><br>
<b><?php  echo $child_brand;?></b></h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="<?php echo get_permalink();?>">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
		 
		 <?php 
		 
		
        
    endwhile;
    wp_reset_postdata();  // Reset the global post object after the loop
 
endif;
		 ?>
 </div> 

			
			
            </div>
            </div>
            </div>
		
   
   <!-- <div class="container-xxl py-5 category project-section">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                
				
				      <h5 class="sub-title  ">Reference <span>projects</span></h5>
		    <h1 class="mb-4   text-center ">Promoting the global energy transition</h1>
            </div>
            <div class="row g-3 project-items">
                <div class=" col-md-12">
                    <div class="row g-3">
                        
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-1.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                    <h5 class="m-0">Project Turkey</h5> 
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-2.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                    <h5 class="m-0">Project Germany</h5> 
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-3.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                    <h5 class="m-0">Project Lebanon</h5>
                                    
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-4.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                  <h5 class="m-0">Project Lebanon</h5>
                                   
                                </div>
                            </a>
                        </div> 
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-5.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                  <h5 class="m-0">Project 49</h5>
                                    
                                </div>
                            </a>
                        </div> 
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-6.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                  <h5 class="m-0">Project F5</h5>
                                     
                                </div>
                            </a>
                        </div> 
                         
                    </div>
                </div>
           
            </div>
        </div>
    </div>--> 
  
 
    <!-- Courses Start -->
    <div class="container-xxl   our-partner-section">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
          
                 <h5 class="sub-title  ">Our Solutions <span>Partners</span></h5>
		    <h1 class="mb-4    ">Who we work with</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-12  wow fadeInUp" data-wow-delay="0.1s">
                    <div class="owl-carousel owl-theme" id="our-partners">
                     
                        <?php  while ( have_rows('partner_logos') ) : the_row(); ?>
                
            <div class="item"><a href="<?php echo get_sub_field('link');?>" target="_blank">
               <div class="partner-block"><img src="<?php echo get_sub_field('image');?>"></div></a> 
            </div>
            <?php   endwhile; ?>
          
			
			<!--
                   <div class="item">
              <a href="https://aepcenergy.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/alternative.jpg"></a>
            </div> 
            	  <div class="item">
             <a href="https://www.aldhow-kw.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/aldow.jpg"></a> 
            </div>-->
          </div>
                </div> 
            </div>
        </div>
    </div>
    <!-- Courses End --><link rel='stylesheet' id='magnific-popup-css'  href='<?php echo get_stylesheet_directory_uri(); ?>/css/magnific-popup.css?ver=4.9.26' type='text/css' media='all' />
 <!-- Courses Start -->
    <div class="container-xxl   our-partner-section home-gallery">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
          
                 <h5 class="sub-title  ">Gallery</span></h5>
		    <h1 class="mb-4    "> A Vision for a Greener Future</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-12  wow fadeInUp" data-wow-delay="0.1s">
             <section class="img-gallery-magnific">
 <?php 
$ivarray = array();
 while ( have_rows('images',382) ) : the_row();
 
if(get_sub_field('display_image_on_home')=="Yes"){ 
$image = get_sub_field('image');
  $ivarray[] = array("thumbs"=>$image["sizes"]["gallery-thumb-small"],"full"=>$image["url"],"type"=>"image");
}
  endwhile;
 while ( have_rows('videos',382) ) : the_row();

$thumbnail = get_sub_field('thumbnail');
if(get_sub_field('display_video_on_home')=="Yes"){  
 $ivarray[] = array("thumbs"=>$thumbnail["sizes"]["gallery-thumb-small"],"full"=>get_sub_field('video'),"type"=>"video");
}
  endwhile;
  foreach($ivarray as $ivarrayitem){
	  if($ivarrayitem["type"]=="image"){
 ?>
			<div class="magnific-img">
				<a class="image-popup-vertical-fit" href="<?php echo $ivarrayitem["full"];?>" title="9.jpg">
					<img src="<?php echo $ivarrayitem["thumbs"];?>"  />
					 
				</a>
			</div>
			
  <?php }
  
  if($ivarrayitem["type"]=="video"){
 ?>
			       <div class="video-box">
				 <a href="<?php echo $ivarrayitem["full"];?>"  class="video-link"  title="Video 11"      > 
              <div class="testimonial" style="background:url('<?php echo $ivarrayitem["thumbs"];?>');background-size:cover;">
             

               <div class="play-icon"><i class="fa fa-play"></i></div>              </div>
				</a>
            </div>
			
  <?php }
		}	?>
		</section>
                </div> 
            </div>
        </div>
		
		<a href="<?php echo site_url('gallery')?>" class="view-gallery">View Gallery</a>
    </div>
    <!-- Courses End -->
  <div class="container-xxl   our-partner-section">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
          
                 <h5 class="sub-title  ">Our <span>Clients</span></h5>
		    <h1 class="mb-4    ">Trusted by Leading Industry Contractors</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-12  wow fadeInUp" data-wow-delay="0.1s">
                    <div class="owl-carousel owl-theme" id="our-clients">
        <?php  while ( have_rows('client_logos') ) : the_row(); ?>
                   <div class="item">
              <a href="<?php echo get_sub_field('link');?>" target="_blank">
                <div class="partner-container">
                    <img src="<?php echo get_sub_field('image');?>"></a>
                </div>
            </div> 
            <?php   endwhile; ?>
            	 
            	  
          </div>
                </div> 
            </div>
        </div>
    </div>
	<?php
	 
	endwhile;  
	get_footer();?> 
<script type='text/javascript' src='<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.magnific-popup.js?ver=20161929'></script> 
	<script>
        setTimeout(() => {
    console.log("remove now")
    document.querySelectorAll('.WidgetBackground__Content-sc-1ho7q3r-2.ciCnpO a:last-of-type').forEach(a => a.remove());

    // Your code goes here
}, 5000); // 5000 milliseconds = 5 seconds

	    $( document ).ready(function() {
		    	 sliderht =   jQuery('.header-video').height()
		 
			 jQuery('.image-background').height(sliderht+'px')	   
			
		//	 jQuery('.image-background').height(sliderht+'px')
	  // Header carousel
	  if(jQuery('.header-video').width() <500){
		   $(".item-desktop").remove()
		   $(".item-mobile").show()
		    // Header carousel
   
	  }else{
		   $(".item-mobile").remove()
		   $(".item-desktop").show()
	
	  }
    
		 $(".header-carousel").owlCarousel({
        autoplay: false,
        smartSpeed: 1500,
        items: 1,
        dots: false,
        loop: true,
        nav : true,
		  onInitialized: callbackht,
        navText : [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ]
    }); 
 
		 }); 
		function callbackht(){
			 
			setTimeout( function(){ 
    	 sliderht =   jQuery('.header-video').height()
		 
			 jQuery('.image-background').height(sliderht+'px')
  }  , 1000 );

    }
	
	function fallback(video)
{
	 
  var img = video.querySelector('img');
  if (img)
    video.parentNode.replaceChild(img, video);
}

	$(document).ready(function(){
$('.image-popup-vertical-fit').magnificPopup({
	type: 'image',
  mainClass: 'mfp-with-zoom', 
  gallery:{
			enabled:true
		},

  zoom: {
    enabled: true, 

    duration: 300, // duration of the effect, in milliseconds
    easing: 'ease-in-out', // CSS transition easing function

    opener: function(openerElement) {

      return openerElement.is('img') ? openerElement : openerElement.find('img');
  }
}

});

});
	</script>
<script>
   $(document).ready(function(){
   
   jQuery(".close-news").click(function(){
   
   boxid = jQuery(this).attr("boxid")
   jQuery(".detailed-news-container-"+boxid).removeClass("active")
   
   });
   jQuery(".news-box").click(function(){
   
   boxid = jQuery(this).attr("boxid")
  
   
   jQuery(".detailed-news-container-"+boxid).addClass("active")
   jQuery('.initiate-first').trigger('click')
   })
   
     
     
       var owl = $("#news-slider").owlCarousel({
           loop: false,
           margin: 10,
           nav: false,
           dots: false,
           autoplay: false,
           autoplayTimeout: 3000,
           autoplayHoverPause: true,
           responsive: {
               0: { items: 1 },
               600: { items: 2 },
               1000: { items: 4 }
           }
       });
   
       $("#prev").click(function() {
           owl.trigger("prev.owl.carousel");
       });
   
       $("#next").click(function() {
           owl.trigger("next.owl.carousel");
       });
   
   });
</script>