<?php 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $featuredimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?> 

 <!-- Header Start -->
    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown"><?php echo get_the_title();?>
</h1>
                    <!---<nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                               <li class="breadcrumb-item"><a class="text-white" href="index.php">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url('services');?>">Services</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page"><?php echo get_the_title();?>
</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

     <!-- About Start -->
    <div class="container-xxl py-5  bg-white about-us-section">
        <div class="container">
            <div class="row g-5">
			
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                   <div class="side-content">
                     <?php the_content();?>
                     
                    <?php 
					
					// Check if the ACF repeater field has rows of data
if( have_rows('brands') ): 
    echo '<ul class="brands-list row">';
    
    // Loop through each row
    while( have_rows('brands') ) : the_row(); 
        
        // Get subfield values
        $image_url = get_sub_field('image'); // Replace 'image' with your actual subfield name
        $link = get_sub_field('link');       // Replace 'link' with your actual subfield name
        
        // Output HTML in list format
        if( $image_url && $link ): 
            echo '<li class="brand-item">';
            echo '<div class="brand-item-box">';
            echo '<a href="' . esc_url($link) . '" target="_blank">';
            echo '<img src="' . esc_url($image_url) . '" alt="Brand">';
            echo '</a>';
            echo '</div>';
            echo '</li>';
        endif;
    
    endwhile;
    
    echo '</ul>';
 
endif;
					?>
                </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 300px;">
                    <div class="position-relative h-100">
                        <div class="service-big" style="background:url(<?php echo $featuredimage[0];?>)" alt=""   ></div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- About End -->

	<?php
	 
	endwhile;  
	get_footer();?>  