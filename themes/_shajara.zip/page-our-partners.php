<?php 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?>
     <!-- Header Start -->
    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Our Partners</h1>
                   <!--- <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url();?>">Home</a></li> 
                            <li class="breadcrumb-item text-white active" aria-current="page">Our Partners</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

<!-- Categories Start -->
    <!-- Courses Start -->
    <div class="container-xxl py-5 our-partner-section">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
          
                 <h5 class="sub-title  ">Our <span>Partners</span></h5>
		    <h1 class="mb-4    ">Who we work with</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-12  wow fadeInUp" data-wow-delay="0.1s">
                    <div class="owl-carousel owl-theme " id="our-partners">
            <div class="item"><a href="https://kaco-newenergy.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/kaco.jpg"></a> 
            </div>
            <div class="item">
             <a href="https://www.solaxpower.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/sola.jpg"></a> 
            </div>
           
            <div class="item">
             <a href="https://www.solaxpower.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/alternative.jpg"></a> 
            </div>
			
			  <div class="item">
             <a href="https://www.aldhow-kw.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/aldow.jpg"></a> 
            </div>
            
          </div>
                </div> 
            </div>
        </div>
    </div>
    <!-- Courses End -->

  	<?php
	 
	endwhile;  
	get_footer();?>  
	 