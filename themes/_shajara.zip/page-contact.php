<?php 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?>
 <style>
 input.wpcf7-form-control.wpcf7-submit {
    color: #fff;
    background-color: rgb(118, 194, 27);
    border-color: rgb(118, 194, 27);
    width: 100%;
    padding-top: 1rem !important;
    padding-bottom: 1rem !important;
    border: 0px;
    font-family: 'Nunito', sans-serif;
    font-weight: 600;
    transition: .5s;
}

 input.wpcf7-form-control.wpcf7-submit:hover {
    color: #fff;
    background-color: #52565b;
    border-color: #52565b;
}
textarea.form-control {
    min-height: calc(1.5em + .75rem + 2px);
    height: 75px;
}
 </style>
  <!-- Header Start -->
    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-10 text-center">
                    <h1 class="display-3 text-white animated slideInDown">Contact</h1>
                <!---    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="<?php echo site_url();?>">Home</a></li>
                             <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                        </ol>
                    </nav>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Contact Start -->
    <div class="container-xxl py-5 contact-main-top">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h5 class="sub-title  ">Contact Us</h5> 
				 <h1 class="mb-4    ">Contact for any query</h1>
            </div>
            <div class="row g-4 contact-main">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h5>Get In Touch</h5>
              <br>
                    <div class="d-flex align-items-center mb-3">
                        <div class="d-flex align-items-center  contact-address justify-content-center flex-shrink-0 bg-primary" style="width: 50px; height: 50px;">
                            <i class="fa fa-map-marker-alt text-white"></i>
                        </div>
                        <div class="ms-3">
                            <h5 class="text-primary">Office</h5>
                            <p class="mb-0">11th floor, Albudor Altejaria Tower, Ahmad Al Jaber St, Kuwait City 13031</p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center mb-3">
                        <div class="d-flex align-items-center justify-content-center flex-shrink-0 bg-primary" style="width: 50px; height: 50px;">
                            <i class="fa fa-phone-alt text-white"></i>
                        </div>
                        <div class="ms-3">
                            <h5 class="text-primary">Contact No</h5>
                            <p class="mb-0">+965 22406044</p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="d-flex align-items-center justify-content-center flex-shrink-0 bg-primary" style="width: 50px; height: 50px;">
                            <i class="fa fa-envelope-open text-white"></i>
                        </div>
                        <div class="ms-3">
                            <h5 class="text-primary">Email</h5>
                            <p class="mb-0">info@alshajara.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3476.605768439805!2d47.986205399999996!3d29.381830299999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fcf85bf4af5f8b7%3A0xdd381d857e216fd2!2sShajara%20Sustainability%20Solutions!5e0!3m2!1sen!2sin!4v1685328855220!5m2!1sen!2sin" width="100%" height="298" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class="col-lg-4 col-md-12 wow fadeInUp" data-wow-delay="0.5s">
                  <?php echo do_shortcode('[contact-form-7 id="8fb1728" title="Contact form"]');?>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->


   
	<?php
	 
	endwhile;  
	get_footer();?>  