
  <!DOCTYPE html>
<html lang="en">

<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-YKF1LF0N5R"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-YKF1LF0N5R');
</script>
    <meta charset="utf-8">
    <title><?php echo get_bloginfo( 'name' );?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/img/3S-logo-fav.jpg" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <!-- Libraries Stylesheet -->
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/lib/animate/animate.min.css" rel="stylesheet">
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/css/style.css" rel="stylesheet">
    <link href="<?php echo get_stylesheet_directory_uri(); ?>/style.css?v=ver<?php echo date('dmYhis');?>" rel="stylesheet">
	   <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<?php wp_head();?> 
<style>
    /* Fix for dropdowns inside dropdowns */
    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu > .dropdown-menu {
        display: none;
        position: absolute;
        left: 100%;
        top: 0;
        margin-top: -5px;
        border-radius: 0.25rem;
    }

    .dropdown-submenu:hover > .dropdown-menu {
        display: block;
    }

    .dropdown-submenu > a::after {
        content: ' ▶';
        float: right;
    }

    .dropdown-menu .dropdown-submenu .dropdown-item::after {
        content: ' ▶';
        float: right;
    }

    .nav-link {
        color: #333 !important;
    }

    .dropdown-menu {
        border-radius: 0.25rem;
    }
    .navbar .nav-item:hover .dropdown-menu .dropdown-menu {
    opacity: 0;display:none;
}
.navbar .nav-item .dropdown-submenu:hover .dropdown-menu {
    opacity: 1;  display:block;
}
.dropdown-menu .dropdown-submenu .dropdown-item::after{
    display:none;
}
.navbar .nav-item .dropdown-submenu:hover .dropdown-menu {
    opacity: 1;
    top: 0px;
}
.dropdown-item:hover, .dropdown-item:focus {
 
    background-color:  #eee;
}

    .navbar .nav-item:hover .dropdown-menu {
     
        border-radius: 0px;padding: 0px;
    }
    
     /* Mobile-friendly adjustments */
    @media (max-width: 991px) {
        .dropdown-menu {
            position: static;
            float: none;
        }

        .dropdown-submenu > .dropdown-menu {
            position: static;
            float: none;
            margin: 0;
            border-radius: 0.25rem;
        }

        .dropdown-submenu > a::after {
            content: '▼';
        }

        .dropdown-menu .dropdown-submenu .dropdown-item::after {
            content: '▼';
        }

        .dropdown-submenu > .dropdown-menu {
            display: none;
        }

        .dropdown-submenu.show > .dropdown-menu {
            display: block;
        }
        .navbar .nav-item .dropdown-submenu:hover .dropdown-menu {
    opacity: 1;
    top: 0px;
    padding-left: 15px;
}

.dropdown-item.active, .dropdown-item:active {
    color: #1e2125; 
}
    }
</style>
	
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar Start -->
   <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
   
          <a href="<?php echo site_url();?>" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/3S-logo-.png">
        </a>
	 
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <?php 
        
            // Array of desired child brand names
            $desired_brands = ['PV Inverters', 'PV Modules', 'PV Cables',  'Battery Storage', 'EV Chargers', 'Monitoring' ];
        $brand = get_term_by('name', 'KACO Solutions', 'brand');
        $kaco = array();
        if ($brand && !is_wp_error($brand)) {
        
            // Get child brands
            $child_brands = get_terms([
                'taxonomy' => 'brand',
                'parent' => $brand->term_id,
                'hide_empty' => false,
            ]);
        
            if (!empty($child_brands) && !is_wp_error($child_brands)) {
                foreach ($child_brands as $child_brand) { 
                    if (in_array($child_brand->name, $desired_brands)) {
                        
                        
                       // echo esc_html($child_brand->name) . ' - ' . esc_html($child_brand->slug) . '<br>';
                         $kaco[$child_brand->name] = "brand/".$child_brand->slug;
            
                    }
                }
            }  
        }  
        $brand = get_term_by('name', 'Huawei', 'brand');
        $huawei = array();
        if ($brand && !is_wp_error($brand)) {
            // Array of desired child brand names
        
            // Get child brands
            $child_brands = get_terms([
                'taxonomy' => 'brand',
                'parent' => $brand->term_id,
                'hide_empty' => false,
            ]);
        
            if (!empty($child_brands) && !is_wp_error($child_brands)) {
                foreach ($child_brands as $child_brand) { 
                    if (in_array($child_brand->name, $desired_brands)) {
                        
                        
                       // echo esc_html($child_brand->name) . ' - ' . esc_html($child_brand->slug) . '<br>';
                         $huawei[$child_brand->name] = "brand/".$child_brand->slug;
            
                    }
                }
            }  
        } 
        $brand = get_term_by('name', 'SolaXPower', 'brand');
        $sola = array();
        if ($brand && !is_wp_error($brand)) {
            // Array of desired child brand names 
        
            // Get child brands
            $child_brands = get_terms([
                'taxonomy' => 'brand',
                'parent' => $brand->term_id,
                'hide_empty' => false,
            ]);
        
            if (!empty($child_brands) && !is_wp_error($child_brands)) {
                foreach ($child_brands as $child_brand) { 
                    if (in_array($child_brand->name, $desired_brands)) {
                        
                        
                       // echo esc_html($child_brand->name) . ' - ' . esc_html($child_brand->slug) . '<br>';
                         $sola[$child_brand->name] = "brand/".$child_brand->slug;
            
                    }
                }
            }  
        } 
        $brand = get_term_by('name', 'Jinko Solar', 'brand');
        $jinko = array();
        if ($brand && !is_wp_error($brand)) {
            // Array of desired child brand names
        
            // Get child brands
            $child_brands = get_terms([
                'taxonomy' => 'brand',
                'parent' => $brand->term_id,
                'hide_empty' => false,
            ]);
        
            if (!empty($child_brands) && !is_wp_error($child_brands)) {
                foreach ($child_brands as $child_brand) { 
                    if (in_array($child_brand->name, $desired_brands)) {
                        
                        
                       // echo esc_html($child_brand->name) . ' - ' . esc_html($child_brand->slug) . '<br>';
                         $jinko[$child_brand->name] = "brand/".$child_brand->slug;
            
                    }
                }
            }  
        } 
        $brand = get_term_by('name', 'Copper Q8', 'brand');
        $copper = array();
        if ($brand && !is_wp_error($brand)) {
            // Array of desired child brand names 
        
            // Get child brands
            $child_brands = get_terms([
                'taxonomy' => 'brand',
                'parent' => $brand->term_id,
                'hide_empty' => false,
            ]);
        
            if (!empty($child_brands) && !is_wp_error($child_brands)) {
                foreach ($child_brands as $child_brand) { 
                    if (in_array($child_brand->name, $desired_brands)) {
                        
                        
                       // echo esc_html($child_brand->name) . ' - ' . esc_html($child_brand->slug) . '<br>';
                         $copper[$child_brand->name] = "brand/".$child_brand->slug;
            
                    }
                }
            }  
        } 
        ?>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a href="<?php echo site_url(); ?>" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo site_url('about'); ?>" class="nav-link">About Us</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo site_url('services'); ?>" class="nav-link">Services</a>
                </li>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Products</a>
                    <ul class="dropdown-menu">

                        <!-- 2nd Level - KACO Solutions -->
                        <?php foreach($desired_brands as $desired_brand) { ?>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#"><?php echo $desired_brand; ?></a>
                            <ul class="dropdown-menu">
                                <?php if($kaco[$desired_brand] !="") { ?>
                                    <li><a class="dropdown-item" href="<?php echo site_url($kaco[$desired_brand]); ?>">KACO</a></li>
                                <?php } ?>
                                <?php if($huawei[$desired_brand] !="") { ?>
                                <li><a class="dropdown-item" href="<?php echo site_url($huawei[$desired_brand]); ?>">Huawei</a></li>
                                <?php } ?>
                                <?php if($sola[$desired_brand] !="") { ?>
                                <li><a class="dropdown-item" href="<?php echo site_url($sola[$desired_brand]); ?>">SolaX Power</a></li>
                                <?php } ?>
                                <?php if($jinko[$desired_brand] !="") { ?>
                                <li><a class="dropdown-item" href="<?php echo site_url($jinko[$desired_brand]); ?>">Jinko Solar</a></li>
                                <?php } ?>
                                <?php if($copper[$desired_brand] !="") { ?>
                                <li><a class="dropdown-item" href="<?php echo site_url($copper[$desired_brand]); ?>">Copper Q8</a></li>
                                <?php } ?> 
                            </ul>
                        </li>
                        
                        <?php } ?>
                          
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="<?php echo site_url('gallery'); ?>" class="nav-link">Gallery</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo site_url('contact'); ?>" class="nav-link">Contact</a>
                </li>
            </ul>
        </div> 
</nav>
<!-- Updated Custom JS to Keep Parent Menu Open -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Enable dropdown submenus on click for mobile
        var dropdowns = document.querySelectorAll('.dropdown-submenu > a');
        dropdowns.forEach(function (dropdown) {
            dropdown.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent closing parent dropdown

                // Close other open submenus at the same level
                var siblingMenus = this.parentElement.parentElement.querySelectorAll('.dropdown-submenu > .dropdown-menu');
                siblingMenus.forEach(function (menu) {
                    if (menu !== this.nextElementSibling) {
                        menu.classList.remove('show');
                    }
                }, this);

                // Toggle the clicked submenu
                var nextEl = this.nextElementSibling;
                if (nextEl && nextEl.classList.contains('dropdown-menu')) {
                    nextEl.classList.toggle('show');
                }
            });
        });

        // Prevent parent dropdown from closing when clicking inside
        var dropdownMenus = document.querySelectorAll('.dropdown-menu');
        dropdownMenus.forEach(function (menu) {
            menu.addEventListener('click', function (e) {
                e.stopPropagation();
            });
        });

        // Close dropdown menus when clicking outside
        document.addEventListener('click', function (e) {
            if (!e.target.closest('.dropdown')) {
                var allMenus = document.querySelectorAll('.dropdown-menu');
                allMenus.forEach(function (menu) {
                    menu.classList.remove('show');
                });
            }
        });
    });
</script>

    <!-- Navbar End -->
