 <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
              <img src="img/3S-logo.jpg">
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="about.php" class="nav-item nav-link ">About Us</a>
                <a href="services.php" class="nav-item nav-link ">Services</a> 
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Products</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="products-kaco.php" class="dropdown-item">KACO solutions</a>
                        <a href="products-solaxpower.php" class="dropdown-item">SolaXPower</a>
 
                    </div>
                </div>
                <a href="our-partners.php" class="nav-item nav-link">Our Partners</a>
                <a href="contact.php" class="nav-item nav-link">Contact</a>
            </div>
           
        </div>
    </nav>
    <!-- Navbar End -->