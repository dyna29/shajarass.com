<?php
	/*
	*Template Name: Home Template 2
	*/ 
	get_header();
	 
	 while ( have_posts() ) : the_post();
	 $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
   
 ?> 
<style>
	.header-carousel video {
    /* height: 498px; */
    width: 100vw!important;
    /* position: fixed; */
    right: 0;
    bottom: 0;
    /* min-width: 100%; */
    /* min-height: 498px; */   
}
.video-container {
   /*  height: calc(70vh - 75px); */
    overflow: hidden;
    width: 100% !important;
}
body {
    background: #eee;
    width: 100vw;
    overflow-x: hidden !important;
}
.image-background{
	background-size:cover !important;
	background-position:center center !important;
	widht:100%;
	height: calc(70vh - 75px);
}
@media (max-width: 477px){
 
.image-background{
	height: 300px !important;
}
.video-container video{
     width: 100%!important;
    height: 300px;
    margin-top: 0px;
    background: #ed8211;
}
}
	</style>
  <!-- Carousel Start -->
    <div class="container-fluid p-0 mb-5">
        <div class="owl-carousel header-carousel position-relative">
		
		 <?php 
	  
			while ( have_rows('slider') ) : the_row();
			$slider_type = get_sub_field('slide_type');
			 $desktop_image__video = get_sub_field('desktop_image__video');
			 $mobile_image__video = get_sub_field('mobile_image__video');
			 $mobile_image__video_gif = get_sub_field('mobile_image__video_gif');
			 $mobile_image__video_mp4 = get_sub_field('mobile_image__video_mp4');
			 $mobile_image__video_webp = get_sub_field('mobile_image__video_webp');
			 $caption_1 = get_sub_field('caption_1');
			 $caption_2 = get_sub_field('caption_2');
			 ?>
            <div class="owl-carousel-item item-desktop position-relative">
			<?php  
			 if($slider_type =='Video'){
				
				 ?>
			<div class="video-container">
                	<video class="header-video"  preload="auto" autoplay="" loop="" muted="" webkit-playsinline="" playsinline="">
    <source src="<?php echo $desktop_image__video; ?>" type="video/mp4">
    	Your browser does not support the video tag.
	</video></div>
	<?php }else{ ?>
	 <div class="image-background" style="background:url('<?php echo $desktop_image__video; ?>" alt=""></div>
	   <?php }  ?>
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" >
				<!--<div class="caption-container">
				<div id="corner"></div>
				<h2><?php echo $caption_1;?></h2>
				<hr>
				<p><?php echo $caption_1;?></p>
				</div>-->
                    
                </div>
            </div>
            <div class="owl-carousel-item item-mobile position-relative">
			<?php  
			 if($slider_type =='Video'){
				
				 ?>
			<div class="video-container">
                	<video class="header-video"  preload="auto" autoplay="" loop="" muted="" webkit-playsinline="" playsinline="">
    <source src="<?php echo $mobile_image__video; ?>" type="video/mp4"  onerror="fallback(parentNode)">
	<img decoding="async" src="<?php echo $mobile_image__video_gif;?>">
    	Your browser does not support the video tag.
	</video></div>
	<?php }else{ ?>
	 <div class="image-background" style="background:url('<?php echo $mobile_image__video; ?>" alt=""></div>
	   <?php }  ?>
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" >
				<!--<div class="caption-container">
				<div id="corner"></div>
				<h2><?php echo $caption_1;?></h2>
				<hr>
				<p><?php echo $caption_1;?></p>
				</div>-->
                    
                </div>
            </div>
			   <?php endwhile;
			?>
          
			
        </div>
    </div>
    <!-- Carousel End -->


    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
		<h5 class="sub-title">Our <span>Service</span></h5>
		    <h1 class="mb-4 text-center ">What we offer</h1>
            <div class="row g-4 our-service-items">
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item text-center pt-3" >
                      
						<div class="service-icon">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/holding-box-white.png" class="icon-white" > 
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/holding-box-color.png" class="icon-color" > 
                         </div> 
                        <div class="p">  <h3>Products provider</h3>
							<p>3S provides variety of sustainable solutions products from world rennin equipment providers!</p>
							
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item text-center pt-3"  >
                         
						<div class="service-icon">
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-flash-on-80-2.png" class="icon-white" > 
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-flash-on-80-1.png" class="icon-color" > 
                         </div>  
                        <div class="p"> 
                            <h3>Energy solutions</h3>
							<p>Complete packages of variety of complete energy solutions that start from finding what suites the clients need</p>
                        </div>
                         
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item text-center pt-3 last-child "  >
                         <div class="service-icon">
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-consultation-80-1.png" class="icon-white" > 
                            <img src="<?php echo site_url(); ?>/wp-content/uploads/2022/12/icons8-consultation-80.png" class="icon-color" > 
                         </div>  
                        <div class="p"> 
                            <h3>Consultancy</h3>
							<p>Technical design, tender preparation, ESG support, …etc.
</p>
                       
                        </div>
                    </div>
                </div>
            
            </div>
        </div>
    </div>
    <!-- Service End -->

    <!-- About Start -->
    <div class="container-fluid  py-5  bg-white about-us-section">
        <div class="container">
            <div class="row  ">
			
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    	<h5 class="sub-title left">About <span>Us</span></h5>
		    <h1 class="mb-4  left ">Who we are</h1>
                    <p class="mb-4">"Shajara Sustainable Solutions (3S) is sustainable energy products and service provider that was established in 2022 in
 Kuwait with focus on providing their services through out the world. 3S is a subsidiary of Al-Shajara holding, which was established for more than 25 years with focus on developing variety of business in the Middle East region."
</p>
                     
                    <a  class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="<?php echo get_stylesheet_directory_uri(); ?>/img/about0us4.jpg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                </div>
			<!--	<div class="row  ">
                <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s"  >
                   <div class="counter-block">
 <div class="row text-center">
	        <div class="col">
	        <div class="counter">
      <i class="fa fa-code fa-2x"></i>
      <h2 class="timer count-title count-number" data-to="100" data-speed="1500"></h2>
       <p class="count-text ">Our Customer</p>
    </div>
	        </div>
           
              <div class="col">
                  <div class="counter">
      <i class="fa fa-lightbulb  fa-2x"></i>
      <h2 class="timer count-title count-number" data-to="11900" data-speed="1500"></h2>
      <p class="count-text ">Project Complete</p>
    </div></div>
              <div class="col">
              <div class="counter">
      <i class="fa fa-bug fa-2x"></i>
      <h2 class="timer count-title count-number" data-to="157" data-speed="12"></h2>
      <p class="count-text ">Partners</p>
    </div>
              </div>
           
         </div>
</div>
                </div>
            </div>-->
        </div>
    </div>
    <!-- About End -->

    <!-- About Start -->
    <div class="container-xxl py-5 founder-section">
        <div class="container">
            <div class="row ">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                    <div class="message-img">
			 <div class="message-img-1" style="background:url(<?php echo get_stylesheet_directory_uri(); ?>/img/fm-2.jpg)"></div>
               <div class="message-img-2" style="background:url(<?php echo get_stylesheet_directory_uri(); ?>/img/fm2.jpg)"></div>
                  </div>
                  </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
              <div class="message-block">
               	<h5 class="sub-title left">Welcome <span>Message</span></h5>
		    <h1 class="mb-4  left ">From the CEO</h1>
                    <p class="founder-message">
					"Suitability is not any more part of the social responsibility or a commodity that only some people can have access to,
 it’s the way to save the planet!"
<span class="founder-name">Hassan Abdullah</span>
<span class="founder-title">CEO</span>
					</p>
                   
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

 
    <!-- Courses Start -->
	<style>
	body{
	background: #eee;
}
.section-padding{
	width:1170px;
	margin: 0 auto;
	padding:80px 0;
}

.owl-item .item {
   transform: translate3d(0, 0, 0); /* DO NOT REMEMBER WHERE TU PUT THIS, SEARCH FOR 3D ACCELERATION */
  // transform: scale(0.9);

  // transition: all .25s ease-in-out;  
 }

.screenshot_slider .owl-item .item .product-item {
background:#fff;
    -webkit-transition: 0.3s;
    -webkit-box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.1);
    -o-transition: 0.3s;
    transition: 0.3s;
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
}

.screenshot_slider .owl-item.center .item .product-item {
    -webkit-transform: scale(1.50);
    -ms-transform: scale(1.50);
    transform: scale(1.50); 
}

.owl-carousel.screenshot_slider  .owl-stage-outer {
   overflow-y:unset !important;
    height: 350px;
}
.screenshot_slider .owl-nav {
    text-align: center;
    // margin: 40px 0;
}
.product-item-pad {
    width: 100%;
    padding: 30px;
}
.screenshot_slider .owl-nav button {
	font-size: 24px !important;
	margin: 10px;
	color: #033aff !important;
}
	</style>
    <div class="container-xxl py-5 products-section" >
		<video playsinline autoplay muted loop>
    <source src="<?php echo get_stylesheet_directory_uri(); ?>/img/v4.mp4" type="video/webm">
    	Your browser does not support the video tag.
	</video>
    <div class="videoContainerTxt">
        <div class="container">
            
          
                 <h5 class="sub-title  ">Our <span>Products</span></h5>
		    <h1 class="mb-4   text-center ">What we offer</h1>
            
	 <div class="screenshot_slider owl-carousel">
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/csm_KNE-blue-LogX-Series_a0ed2115c6.png" alt="" title=""> 
			 </div>
		 <div class="description">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/kaco.jpg">
			 <h4>blue'Log X-series</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div> 
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/csm_KNE-blueplanet-50TL3-RPonly-2_43b03c361e.png" alt="" title=""> </div>
		 <div class="description">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/kaco.jpg">
			 <h4>blueplanet 50.0 TL3 RPonly</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/csm_KNE-bp-hybrid-SPI_5f70a294ff.png" alt="" title=""> </div>
		 <div class="description">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/kaco.jpg">
			 <h4>blueplanet hybrid 10.0 TL3</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/csm_KNE-Erweiterungsmodul-TLX_8af4223f66.png" alt="" title=""> </div>
		 <div class="description">
			<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/kaco.jpg">
			 <h4>Digital Inputs Extension Module</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/EV-CHARGER.png" alt="" title=""> </div>
		 <div class="description">
			<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/sola.jpg">
			 <h4>Smart EV Charger</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/SOLAX SINGLE PHASE X1 MINI - STRING INVERTER.jpg" alt="" title=""> </div>
		 <div class="description">
			<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/sola.jpg">
			 <h4>SolaX Single Phase X1 Mini – String Inverter</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/TriplePowerLFPwebproduct-1004x1024.png" alt="" title=""> </div>
		 <div class="description">
			<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/sola.jpg">
			 <h4>Solax Triple Power Battery - LFP</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
		 <div class="item">
		 <div class="product-item-pad">
		 <div class="product-item">
		 <div class="img-box">
			 <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/products/webhybridfront-1004x1024-1.png" alt="" title=""> </div>
		 <div class="description">
			<img src="<?php echo get_stylesheet_directory_uri(); ?>/img/sola.jpg">
			 <h4>Solax Single Phase Hybrid - High Voltage</h4>
			 <a class="btn btn-primary py-3 px-5 mt-2" style="border-radius: 30px;" href="">Read More</a>
		 </div>
		 </div>
		 </div>
		 </div>
	</div> 

			
			
            </div>
            </div>
            </div>
		
   
   <!-- <div class="container-xxl py-5 category project-section">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                
				
				      <h5 class="sub-title  ">Reference <span>projects</span></h5>
		    <h1 class="mb-4   text-center ">Promoting the global energy transition</h1>
            </div>
            <div class="row g-3 project-items">
                <div class=" col-md-12">
                    <div class="row g-3">
                        
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-1.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                    <h5 class="m-0">Project Turkey</h5> 
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-2.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                    <h5 class="m-0">Project Germany</h5> 
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-3.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                    <h5 class="m-0">Project Lebanon</h5>
                                    
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-4.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                  <h5 class="m-0">Project Lebanon</h5>
                                   
                                </div>
                            </a>
                        </div> 
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-5.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                  <h5 class="m-0">Project 49</h5>
                                    
                                </div>
                            </a>
                        </div> 
                        <div class="col-lg-4 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img class="img-fluid" src="<?php echo get_stylesheet_directory_uri(); ?>/img/project-6.jpg" alt="">
                                <div class="bg-white text-center position-absolute bottom-0 end-0 py-2 px-3" style="margin: 1px;">
                                  <h5 class="m-0">Project F5</h5>
                                     
                                </div>
                            </a>
                        </div> 
                         
                    </div>
                </div>
           
            </div>
        </div>
    </div>-->
 
    <!-- Courses Start -->
    <div class="container-xxl   our-partner-section">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
          
                 <h5 class="sub-title  ">Our <span>Partners</span></h5>
		    <h1 class="mb-4    ">Who we work with</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-12  wow fadeInUp" data-wow-delay="0.1s">
                    <div class="owl-carousel owl-theme" id="our-partners">
            <div class="item"><a href="https://kaco-newenergy.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/kaco.jpg"></a> 
            </div>
            <div class="item">
             <a href="https://www.solaxpower.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/sola.jpg"></a> 
            </div>
                   <div class="item">
              <a href="https://aepcenergy.com/" target="_blank">
               <img src="<?php echo get_stylesheet_directory_uri(); ?>/img/alternative.jpg"></a>
            </div> 
            
          </div>
                </div> 
            </div>
        </div>
    </div>
    <!-- Courses End -->

  

	<?php
	 
	endwhile;  
	get_footer();?>  
	<script>
	    $( document ).ready(function() {
		    	 sliderht =   jQuery('.header-video').height()
		 
			 jQuery('.image-background').height(sliderht+'px')	   
			
		//	 jQuery('.image-background').height(sliderht+'px')
	  // Header carousel
	  if(jQuery('.header-video').width() <500){
		   $(".item-desktop").remove()
		   $(".item-mobile").show()
		    // Header carousel
   
	  }else{
		   $(".item-mobile").remove()
		   $(".item-desktop").show()
	
	  }
    
		 $(".header-carousel").owlCarousel({
        autoplay: false,
        smartSpeed: 1500,
        items: 1,
        dots: false,
        loop: true,
        nav : true,
		  onInitialized: callbackht,
        navText : [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ]
    }); 
 
		 }); 
		function callbackht(){
			 
			setTimeout( function(){ 
    	 sliderht =   jQuery('.header-video').height()
		 
			 jQuery('.image-background').height(sliderht+'px')
  }  , 1000 );

    }
	
	function fallback(video)
{
	 
  var img = video.querySelector('img');
  if (img)
    video.parentNode.replaceChild(img, video);
}
	</script>
	
	 