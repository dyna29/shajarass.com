<?php
@ini_set( 'upload_max_size' , '128M' );
@ini_set( 'post_max_size', '128M');
@ini_set( 'max_execution_time', '300' );
show_admin_bar(false);
if (function_exists('add_theme_support')) {
    add_theme_support('post-thumbnails');
    add_theme_support('widgets');
    add_post_type_support('page', 'excerpt');
    register_nav_menus(array(
        'primary' => __('Primary Navigation', 'shajara')
    )); 
     add_image_size('gallery-thumb-small', 382, 310, true);  
 
}
 
if (!is_admin()) {
    function de_script()
    {
        wp_dequeue_script('jquery');
        wp_deregister_script('jquery');
        wp_register_script('jquery', get_stylesheet_directory_uri() . '/js/core.min.js', false, null);
        wp_enqueue_script('jquery');
    }
   add_action('wp_print_scripts', 'de_script', 10);
}
 
 

 
 
function custom_post_init()
{
 
    
    $labels = array(
        'name' => _x('Product', 'post type general name', 'shajara'),
        'singular_name' => _x('Product', 'post type singular name', 'shajara'),
        'menu_name' => _x('Products', 'admin menu', 'shajara'),
        'name_admin_bar' => _x('Product', 'add new on admin bar', 'shajara'),
        'add_new' => _x('Add New Product', 'hotel', 'shajara'),
        'add_new_item' => __('Add New Product', 'shajara'),
        'new_item' => __('New Product', 'shajara'),
        'edit_item' => __('Edit Product', 'shajara'),
        'view_item' => __('View Product', 'shajara'),
        'all_items' => __('All Products', 'shajara'),
        'search_items' => __('Search Products', 'shajara'),
        'parent_item_colon' => __('Parent Products:', 'shajara'),
        'not_found' => __('No Products found.', 'shajara'),
        'not_found_in_trash' => __('No Products found in Trash.', 'shajara')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'shajara'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'product'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            'excerpt', 'page-attributes',
        )
    );
    register_post_type('product', $args);
	
	  $labels = array(
        'name' => _x('News', 'post type general name', 'shajara'),
        'singular_name' => _x('News', 'post type singular name', 'shajara'),
        'menu_name' => _x('News', 'admin menu', 'shajara'),
        'name_admin_bar' => _x('News', 'add new on admin bar', 'shajara'),
        'add_new' => _x('Add New News', 'hotel', 'shajara'),
        'add_new_item' => __('Add New News', 'shajara'),
        'new_item' => __('New News', 'shajara'),
        'edit_item' => __('Edit News', 'shajara'),
        'view_item' => __('View News', 'shajara'),
        'all_items' => __('All News', 'shajara'),
        'search_items' => __('Search News', 'shajara'),
        'parent_item_colon' => __('Parent News:', 'shajara'),
        'not_found' => __('No News found.', 'shajara'),
        'not_found_in_trash' => __('No News found in Trash.', 'shajara')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'shajara'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'news'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            'excerpt', 'page-attributes',
        )
    );
    register_post_type('news', $args);
	$labels = array(
        'name' => _x('Team', 'post type general name', 'shajara'),
        'singular_name' => _x('Team', 'post type singular name', 'shajara'),
        'menu_name' => _x('Teams', 'admin menu', 'shajara'),
        'name_admin_bar' => _x('Team', 'add new on admin bar', 'shajara'),
        'add_new' => _x('Add New Team', 'hotel', 'shajara'),
        'add_new_item' => __('Add New Team', 'shajara'),
        'new_item' => __('New Team', 'shajara'),
        'edit_item' => __('Edit Team', 'shajara'),
        'view_item' => __('View Team', 'shajara'),
        'all_items' => __('All Teams', 'shajara'),
        'search_items' => __('Search Teams', 'shajara'),
        'parent_item_colon' => __('Parent Teams:', 'shajara'),
        'not_found' => __('No Teams found.', 'shajara'),
        'not_found_in_trash' => __('No Teams found in Trash.', 'shajara')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'shajara'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'team'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            'excerpt', 'page-attributes',
        )
    );
    register_post_type('team', $args);
    $labels = array(
        'name' => _x('Service', 'post type general name', 'shajara'),
        'singular_name' => _x('Service', 'post type singular name', 'shajara'),
        'menu_name' => _x('Services', 'admin menu', 'shajara'),
        'name_admin_bar' => _x('Service', 'add new on admin bar', 'shajara'),
        'add_new' => _x('Add New Service', 'hotel', 'shajara'),
        'add_new_item' => __('Add New Service', 'shajara'),
        'new_item' => __('New Service', 'shajara'),
        'edit_item' => __('Edit Service', 'shajara'),
        'view_item' => __('View Service', 'shajara'),
        'all_items' => __('All Services', 'shajara'),
        'search_items' => __('Search Services', 'shajara'),
        'parent_item_colon' => __('Parent Services:', 'shajara'),
        'not_found' => __('No Services found.', 'shajara'),
        'not_found_in_trash' => __('No Services found in Trash.', 'shajara')
    );
    $args   = array(
        'labels' => $labels,
        'description' => __('Description.', 'shajara'),
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'service'
        ),
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array(
            'title',
            'editor',
            'thumbnail',
            'thumbnail',
            'excerpt', 'page-attributes',
        )
    );
    register_post_type('service', $args);
	
	 
	   	   
    
    
	
	 
	   	   
}
add_action('init', 'custom_post_init');


function custom_taxonomy_init()
{
    
    
        $labels = array(
        'name' => _x('Brand', 'taxonomy general name'),
        'singular_name' => _x('Brand', 'taxonomy singular name'),
        'search_items' => __('Search Brand'),
        'all_items' => __('All Brand'),
        'parent_item' => __('Parent Brand'),
        'parent_item_colon' => __('Parent Brand:'),
        'edit_item' => __('Edit Brand'),
        'update_item' => __('Update Brand'),
        'add_new_item' => __('Add New Brand'),
        'new_item_name' => __('New Brand'),
        'menu_name' => __('Brand')
    );
    
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
           'show_ui' => true,
            'show_in_rest' => true,
            'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => 'brand',
			  'with_front' => false
        )
    );
    register_taxonomy('brand', array(
        'product'
    ), $args);
	
        
     
 
}
add_action('init', 'custom_taxonomy_init');

/** remove editor dashboard menu
*/ define( 'DISALLOW_FILE_EDIT', true);
 
function remove_menus(){

  remove_menu_page( 'index.php' );                  //Dashboard  
  remove_menu_page( 'jetpack' );                    //Jetpack*   // 
  remove_menu_page( 'upload.php' );                 //Media   
  remove_menu_page( 'edit.php?post_type=service' );    //Pages  
  remove_menu_page( 'edit.php?post_type=page' );    //Pages  
  remove_menu_page( 'edit-comments.php' );          //Comments  
  remove_submenu_page('edit.php', 'edit-tags.php?taxonomy=category');
    remove_submenu_page('edit.php', 'edit-tags.php?taxonomy=post_tag');
  remove_menu_page( 'themes.php' );                 //Appearance  
  remove_menu_page( 'plugins.php' );                //Plugins  
  remove_menu_page( 'users.php' );                  //Users  
  remove_menu_page( 'tools.php' );                  //Tools  
  remove_menu_page( 'options-general.php' );        //Settings
  remove_menu_page( 'wpcf7' );        //contact form

}

if ( current_user_can( 'editor' ) ){
    add_action( 'admin_menu', 'remove_menus' );
}
 
 function remove_dashboard_meta() {
remove_meta_box( 'dashboard_incoming_links', 'dashboard', 'normal' );
remove_meta_box( 'dashboard_plugins', 'dashboard', 'normal' );
remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
remove_meta_box( 'dashboard_secondary', 'dashboard', 'normal' );
remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
remove_meta_box( 'dashboard_recent_drafts', 'dashboard', 'side' );
remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
remove_meta_box( 'dashboard_right_now', 'dashboard', 'normal' );
remove_meta_box( 'dashboard_activity', 'dashboard', 'normal');//since 3.8
}
add_action( 'admin_init', 'remove_dashboard_meta' );


 //add_action( 'admin_menu', 'import_register_ref_page' );
function import_register_ref_page() {
    
  
  add_submenu_page(
        'edit.php?post_type=product',
        __( 'Import', 'textdomain' ),
        __( 'Import', 'textdomain' ),
        'manage_options',
        'import-projcts',
        'import_projects_csv2'
    );  
}


function import_projects_csv2() { 
    ?>
    <div class="wrap">
        <h1><?php _e( 'Import Products From CSV', 'textdomain' ); ?></h1>
        <p><?php _e( 'Upload CSV', 'textdomain' ); ?></p>
    </div>
  <?php
  global $wpdb;
    $DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];
    $filename= $DOCUMENT_ROOT. '/wp-content/themes/shajara/evHuawei.csv';
    
     $file_data = fopen($filename, 'r');
     $column    = fgetcsv($file_data);
      $i         = 0;
		$html = '<table border="1">';
		$html .= '<tr>';
		$html .= '<td> Sr';
		$html .= '</td>';
		$html .= '<td> Datasheet';
		$html .= '</td>';
		$html .= '<td> Item Title';
		$html .= '</td>';
		$html .= '<td> Phase';
		$html .= '</td>';
		$html .= '<td> Category';
		$html .= '</td>';
		$html .= '<td> Features';
		$html .= '</td>';
		 
		$html .= '</tr>';
	  	 while ($row = fgetcsv($file_data)) {
            $i++;  
			
    $html .= '<tr>';
		$html .= '<td> '. $i;
		$html .= '</td>';
		$html .= '<td> '. $row[1];
		$html .= '</td>';
		$html .= '<td> '. $row[2];
		$html .= '</td>';
		$html .= '<td> '. $row[3];
		$html .= '</td>';   
		$html .= '<td> '. $row[4];
		$html .= '</td>';   
		$html .= '<td> '. $row[0];
		$html .= '</td>';   
 
		$html .= '</tr>';
$phase = $row[2];
if($row[2]=='NA'){
	$phase = '';
}		
global $wpdb;
	  $new_post = array(
          
        'post_author' => get_current_user_id(),   
        'post_title' => $row[1],
          'post_type' => 'product',
          'post_parent' => 0,
          'post_status' => 'publish',
       
       ); 
     $post_id = wp_insert_post($new_post);
	
		 
		 
		 
		    $sql = 	'INSERT INTO  wp_postmeta (post_id,meta_key,meta_value) values ('.$post_id.' , "_phase" ,   "field_66c8645604cfe" )  ' ; 
         $wpdb->query($sql);
         $sql = 	'INSERT INTO  wp_postmeta (post_id,meta_key,meta_value) values ('.$post_id.',   "phase" , "'.$phase.'"  )  ' ; 
         $wpdb->query($sql);  
		 
		 
		    $sql = 	'INSERT INTO  wp_postmeta (post_id,meta_key,meta_value) values ('.$post_id.' , "_phase" ,   "field_6686975dde8e8" )  ' ; 
         $wpdb->query($sql);
         $sql = 	'INSERT INTO  wp_postmeta (post_id,meta_key,meta_value) values ('.$post_id.',   "content" , "'.$row[4].'"  )  ' ; 
         $wpdb->query($sql);   
		 $project_categories  =array();
		  $project_categories[] = 17;  
		   $project_categories[] =  26; 
	 
	 
	  
 wp_set_object_terms($post_id,$project_categories,'brand');
 $ds = str_replace(".pdf","",$row[0]);
 $sql = "select id from wp_posts where  post_type='attachment' and post_title = '".$ds."'";
 
 $datasheet = $wpdb->get_var($sql);
   $sql = 	'INSERT INTO  wp_postmeta (post_id,meta_key,meta_value) values ('.$post_id.' , "_datasheet" ,   "field_66864bae7effc" )  ' ; 
         $wpdb->query($sql);
         $sql = 	'INSERT INTO  wp_postmeta (post_id,meta_key,meta_value) values ('.$post_id.',   "datasheet" , "'.$datasheet.'"  )  ' ; 
         $wpdb->query($sql);
	 
		 }
            $html .= '</table>';
		echo $html; 
	
    }


function custom_product_permalink( $permalink, $post, $leavename ) {
 
    // Check if the post type is 'product'
      if ( 'product' == $post->post_type ) {
 
        // Get the brand term associated with the product
        $terms = wp_get_post_terms( $post->ID, 'brand' ,        // Taxonomy name (replace 'brand' with your custom taxonomy name)
    array(
        'orderby' => 'parent',  // Order by parent ID
        'order'   => 'ASC'      // 'ASC' for ascending, 'DESC' for descending
    ));
		
		$brand_slug = array();
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			foreach($terms  as $term){
           
			$brand_slug[] = $term->slug; // Get the brand slug
			} 
			}
			
			$brand_slug = implode("/",$brand_slug);
			 
            // Modify the permalink structure
         $permalink = home_url( "/product/".$brand_slug."/" . $post->post_name . '/' );
			 
       
    }  
    return $permalink;
}
add_filter( 'post_type_link', 'custom_product_permalink', 10, 3 );

function custom_rewrite_rules() {
    // Custom rewrite rule to handle the brand and child term structure
    add_rewrite_rule(
        '^product/([^/]+)/([^/]+)/([^/]+)/?$',
        'index.php?product=$matches[3]', // Match the URL structure and redirect to the product post
        'top'
    );
}
add_action('init', 'custom_rewrite_rules');
