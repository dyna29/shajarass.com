<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u806441573_YmR5n' );

/** Database username */
define( 'DB_USER', 'u806441573_Ke5wn' );

/** Database password */
define( 'DB_PASSWORD', 'MX2foN4Vwf' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ')Laz(88}nK#YTwL$6LYO1W0FCG]g{wSWffkjM2yu1L:e+!@j-/[5$D?wbbcYa:J.' );
define( 'SECURE_AUTH_KEY',   ']Z:RYo7rw:j3nukhWJ|3P_.Mg]X l%EWd*17 c7Y!1%8~&^.s|b/As}z2Yi[<l&?' );
define( 'LOGGED_IN_KEY',     '(*14Zihpg8YU5YfA4SRIPEpJ&m/>|g+r$jZLPu=f=Q1EQ2A@.t0n~E+IU^lh#i{l' );
define( 'NONCE_KEY',         'Uj C!v73%mo>U]4e(QoC $Z9XYz5l4shr,FTw 3ZlCw5$e^k3h>Hb& v*q.8$Uw:' );
define( 'AUTH_SALT',         'K)D2 kh#^V3=,<Z7uAMz-S[BC,dI|;,D=Iq~D^t)9phvBUX}I[dnP26J+~?J?+WO' );
define( 'SECURE_AUTH_SALT',  'N5?A yg[POg52_Eg9Ir0vNdkcHF/DK=tKho.hk#H$GJqr@{j5n.6ut(WeR08GZH*' );
define( 'LOGGED_IN_SALT',    'ZuY$YTX:8j>jH7bQ|Sn|nZL<|{@Wb1XHwvF(bXqWMzh%co}~)iWTEp/rwh}/#gPb' );
define( 'NONCE_SALT',        'e-ZP>QT.mvdrQg]%y1n7>ZJf3 UVW[$ 5G_%@B`5L9xS`_zHr6j]D=/ c-yW$m %' );
define( 'WP_CACHE_KEY_SALT', '6odH*z f6b83#dIl*7^f#k8P3)U*<P5zyADz;eHMf}]c#$%Y_Y.U(leN@};@m*(W' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', '8b59bc512fe5bf568145d7cc7db39049' );
define( 'WP_AUTO_UPDATE_CORE', false );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
